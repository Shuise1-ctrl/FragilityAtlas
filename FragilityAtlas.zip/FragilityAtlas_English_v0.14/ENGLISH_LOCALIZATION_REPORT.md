# English localization report

Date: 2026-11-23. Basis: the latest local FragilityAtlas application source, reporting runtime version **0.14**. The Chinese source was backed up independently before this release copy was edited.

## Scope and files

- `out/index.html`, `out/locale-en.js`, `out/source-profile-en.json`: English as the default language; centralized translation of navigation, page headings, controls, notices, tooltips, and source-specific explanatory text in the presentation layer.
- `out/curves-app.js`, `out/offline-data.js`, `out/english-refinement.css`: direct-file data loading and source-profile translation, plus compact typography and wrapped navigation. `offline-data.js` is a generated copy of the public-safe JSON snapshot; no source parameters were edited.
- `out/experience-v8.js`, `out/experience-v11.js`, `out/experience-v12.js`, `out/agent-workflow.js`: English page content and curve export presentation, including English building labels and Times New Roman SVG export text. Original records remain the source for scientific values.
- `server.py`, `agent_workflow.py`, and `agent_tools/collector/{models,pipeline,search,storage,web}.py`: English API errors, task stages, downloadable CSV headers, and messages. The runtime now resolves the database relative to its release directory and does not read a private machine-specific `.env` fallback.
- `README.md`, `CHANGELOG.md`, `docs/TERMINOLOGY.md`, `start-workbench.cmd`: English documentation and portable launch command.

The historical Chinese database builder/audit scripts were preserved in the separate source backup and omitted from this portable runtime. The bundled document-specific PDF extraction algorithms were not rewritten.

## Terminology

The UI and documentation use **Basic Information**, **Fragility Database**, **Japan Classic Curves**, **Literature Agent Workbench**, **DeepSeek-assisted literature retrieval**, **PDF-based function extraction**, **candidate function records**, **source verification**, **ground-motion intensity measure (IM)**, and **damage-state exceedance probability**. DeepSeek assists retrieval/screening; local Python code handles PDF localization and adapted-paper parameter extraction.

## Public-path exception and scientific invariants

The Chinese source JSON contained **9,150 local absolute-path values** in `Source_Path` and nested audit/evidence path fields. Publishing them would disclose private machine paths. The English release therefore contains a **public-safe derivative snapshot**: each local path value was replaced with `[local source file withheld]` plus its basename. The three record-chunk filenames were updated to reflect their new SHA-256 hashes, and `curves.json` references the new names. The private path mapping is not included in this release.

An object-by-object comparison against the unmodified Chinese backup found **zero differences outside those 9,150 path strings** before the three chunk references were renamed. Function parameters, `Curve_ID`, `Group_ID`, source titles, DOI strings, original labels, original-source table/page locators, and all other evidence values compare equal after JSON parsing. The original byte-identical JSON files remain in `FragilityAtlas_Chinese_v0.14_source_backup.zip` outside this GitHub draft ZIP. This path-redaction exception must be reviewed before public publication; the public files are intentionally not byte-identical to the original private JSON.

## Remaining original-language text

The browser audit covered Basic Information, default and all 15 country-filtered database views, a curve dialog, six Japan views, and the Agent page. The final visible Chinese/Japanese characters were confined to original publication titles and original building codes (`木造`, `非木造`). These are source metadata and remain unchanged as required. Source-specific Japanese damage labels are translated in the presentation layer; their original values remain in JSON and raw data exports. No unresolved Chinese interface label was found in this audit.

## Tested and not tested

See `SMOKE_TEST_REPORT.md`. Online DeepSeek/Serper/Kuntin search was **not tested: API key/search service not configured**. Generic PDF smoke testing does not establish parameter extraction accuracy for arbitrary papers. The public snapshot is read-only; human source verification is separate from publication.
