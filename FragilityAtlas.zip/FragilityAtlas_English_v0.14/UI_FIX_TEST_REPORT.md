# English UI correction and screenshot test

Date: 2026-11-23 (Asia/Shanghai)

## Changes

- The top-left brand reads only **FragilityAtlas**.
- The PDF upload control on the Literature Agent Workbench uses an English button and filename status instead of a native browser file-input label that follows the Windows display language.
- Display-only translations were added for the remaining Chinese building and source labels. Original JSON records, curve parameters, IDs, and evidence were not edited.

## Results

- Browser language: `zh-CN`; English visible-text audit: no Chinese text or attributes in the four default pages, 15 country-filtered database views, Japan curve detail, and PGA/PGV/SI/JMA/RSI views.
- PDF picker: `No file selected` before selection; `example.pdf` after a synthetic file was selected; no visible Chinese native file-input text.
- Four navigation pages loaded without browser script errors in the integrated local server.
- Direct `file://` mode: 2,018 applicability records, 15 country cards, 304 Japan applicability records, 24 Japan curve cards on the first page, and a functional curve-detail plot.
- JavaScript syntax checks passed for `agent-workflow.js` and `locale-en.js`.
- Four page screenshots and three composites exported in PNG, TIFF, and SVG. PNG and TIFF pixels match exactly, SVG files parse, and PNG/TIFF carry 1,200 dpi print metadata. The SVG screenshot panels embed lossless raster PNGs; the browser UI itself is not vectorized.

The figure exports are supplied separately under the requested `出图/图1` directory and are not included in the GitHub source ZIP.
