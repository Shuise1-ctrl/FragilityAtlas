"""Local, review-gated literature acquisition and PDF extraction jobs.

The published curve snapshot is deliberately never modified by these jobs.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT / "agent_tools"
WORK = ROOT / "agent_workspace"
BACKEND = TOOLS / "fragility_pipeline.py"
FIELDS = ["Country", "Building_Type", "Seismic_Level", "Damage_State", "Condition",
          "Function_Type", "Function_Expression", "Inputs", "a", "b", "c", "d",
          "e", "Parameter_Names", "Output", "Source", "Notes"]
POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix="fragility-agent")
JOBS: dict[str, dict] = {}
LOCK = threading.Lock()


def _configuration() -> Path | None:
    candidates = [os.environ.get("FRAGILITY_AGENT_CONFIG", ""),
                  str(TOOLS / ".env")]
    return next((Path(p) for p in candidates if p and Path(p).is_file()), None)


def readiness() -> dict:
    config = _configuration()
    keys = {}
    if config:
        for line in config.read_text(encoding="utf-8-sig").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                if k.strip() in {"DEEPSEEK_API_KEY", "SERPER_API_KEY", "COLLECTOR_SEARCH_ENGINE"}:
                    keys[k.strip()] = v.strip().strip("\"'")
    engine = os.environ.get("COLLECTOR_SEARCH_ENGINE") or keys.get("COLLECTOR_SEARCH_ENGINE", "serper")
    llm = bool(os.environ.get("DEEPSEEK_API_KEY") or keys.get("DEEPSEEK_API_KEY"))
    search = engine == "kuntin" or bool(os.environ.get("SERPER_API_KEY") or keys.get("SERPER_API_KEY"))
    return {"local": True, "search_ready": bool(llm and search), "deepseek_ready": llm,
            "engine": engine, "pdf_ready": BACKEND.is_file(),
            "configuration": "local configuration present" if config else "no local .env found"}


def _job(kind: str, title: str) -> dict:
    job = {"id": uuid.uuid4().hex[:12], "kind": kind, "title": title,
           "status": "queued", "stage": "Waiting to run", "error": "", "result": {}}
    with LOCK:
        JOBS[job["id"]] = job
    return job


def get_job(job_id: str) -> dict | None:
    with LOCK:
        job = JOBS.get(job_id)
        return json.loads(json.dumps(job, ensure_ascii=False)) if job else None


def list_jobs() -> list[dict]:
    with LOCK:
        return [{k: v for k, v in job.items() if k != "result"}
                for job in reversed(list(JOBS.values()))]


def _set(job: dict, **changes) -> None:
    with LOCK:
        job.update(changes)


def _safe_snippet(value: str, limit: int = 340) -> str:
    return re.sub(r"\s+", " ", value).strip()[:limit]


def start_search(country: str, building: str, im: str,
                 deepseek_api_key: str = "", serper_api_key: str = "") -> dict:
    country, building, im = (_safe_snippet(x, 100) for x in (country, building, im))
    if not country or not building or not im:
        raise ValueError("Enter the study country, building type, and ground-motion intensity measure (IM).")
    if not re.fullmatch(r"[\w\u4e00-\u9fff ,./()\-+]+", country + building + im):
        raise ValueError("The search criteria contain unsupported characters.")
    deepseek_api_key, serper_api_key = deepseek_api_key.strip(), serper_api_key.strip()
    if len(deepseek_api_key) > 4096 or len(serper_api_key) > 4096:
        raise ValueError("The API key exceeds the length limit.")
    objective = (f"Find peer-reviewed, original earthquake seismic fragility studies for {country}; "
                 f"building type {building}; intensity measure {im}. Locate papers with fragility "
                 "functions, numerical parameter tables or digitizable curve figures, damage states, "
                 "DOI and full-text PDF. Exclude flood, tsunami, GEM and ESRM20 model libraries. "
                 "Use multilingual terms including 地震易损性曲线, seismic fragility curve, "
                 "earthquake vulnerability, lognormal exceedance, fragility parameters, "
                 "filetype:pdf, site:edu, site:ac.jp, and DOI when relevant.")
    job = _job("search", f"{country} · {building} · {im}")
    # User keys exist only in this queued call; jobs and output files contain no credentials.
    POOL.submit(_run_search, job, objective, deepseek_api_key, serper_api_key)
    return get_job(job["id"])


def _csv_rows(path: Path, limit: int = 120) -> list[dict]:
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))[:limit]


def _run_search(job: dict, objective: str, deepseek_api_key: str,
                serper_api_key: str) -> None:
    _set(job, status="running", stage="DeepSeek-assisted query planning, retrieval, screening, and download")
    try:
        sys.path.insert(0, str(TOOLS))
        from collector import ResearchPipeline, Settings
        from collector.config import _load_env_file
        config = _configuration()
        if config:
            _load_env_file(config)
        settings = replace(Settings.from_env(), output_root=WORK / "search" / job["id"])
        if deepseek_api_key:
            settings = replace(settings, deepseek_api_key=deepseek_api_key)
        if serper_api_key:
            settings = replace(settings, serper_api_key=serper_api_key)
        settings.validate()
        pipeline = ResearchPipeline(settings)
        try:
            report = pipeline.run(objective)
        finally:
            pipeline.close()
        folder = report.parent
        downloads = _csv_rows(folder / "downloads.csv")
        result = {"objective": objective, "folder": str(folder),
                  "queries": _csv_rows(folder / "search_queries.csv"),
                  "search_results": _csv_rows(folder / "search_results.csv"),
                  "downloads": downloads,
                  "downloaded_pdfs": [{"path": row.get("Local_File", ""), "title": row.get("Title", ""),
                                       "sha256": row.get("SHA256", "")}
                                      for row in downloads if row.get("Status") == "downloaded"
                                      and row.get("Local_File", "").lower().endswith(".pdf")],
                  "report": str(report)}
        _set(job, status="complete", stage="Literature retrieval and PDF download complete", result=result)
    except Exception as exc:
        _set(job, status="failed", stage="Literature retrieval or PDF download failed", error=_safe_snippet(str(exc), 700))


def save_upload(filename: str, data: bytes) -> dict:
    if not data.startswith(b"%PDF-") or len(data) > 50 * 1024 * 1024:
        raise ValueError("Only PDF files up to 50 MB are accepted.")
    name = Path(filename).name
    if not name.lower().endswith(".pdf"):
        raise ValueError("The file extension must be .pdf.")
    sha = hashlib.sha256(data).hexdigest()
    folder = WORK / "uploads" / sha[:16]
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / re.sub(r"[^\w.\-]+", "_", name)[:100]
    if not path.exists():
        path.write_bytes(data)
    return {"path": str(path), "sha256": sha, "name": name}


def _allowed_pdf(path: str) -> Path:
    pdf = Path(path).resolve()
    base = WORK.resolve()
    if not pdf.is_relative_to(base) or not pdf.is_file() or pdf.suffix.lower() != ".pdf":
        raise ValueError("Only PDFs downloaded or uploaded in this workbench can be parsed.")
    return pdf


def start_extract(path: str, country: str = "") -> dict:
    pdf = _allowed_pdf(path)
    job = _job("extract", pdf.name)
    POOL.submit(_run_extract, job, pdf, _safe_snippet(country, 100))
    return get_job(job["id"])


def _locate(pdf: Path) -> list[dict]:
    from pypdf import PdfReader
    result = []
    pat = re.compile(r"fragility|vulnerability|exceedance|damage state|易损|脆弱|损伤状态|易损性", re.I)
    table = re.compile(r"table\s*\d+|figure\s*\d+|fig\.\s*\d+|表\s*\d+|图\s*\d+", re.I)
    for number, page in enumerate(PdfReader(str(pdf)).pages, 1):
        raw = page.extract_text() or ""
        if not pat.search(raw):
            continue
        hits = [m.group(0) for m in list(table.finditer(raw))[:8]]
        result.append({"page": number, "labels": hits, "snippet": _safe_snippet(raw, 500)})
    return result


def _key(row: dict) -> str:
    fields = ["Country", "Building_Type", "Seismic_Level", "Damage_State", "Condition",
              "Function_Type", "Function_Expression", "Inputs", "a", "b", "c", "d", "e"]
    normalized = [re.sub(r"\s+", "", str(row.get(k, "")).casefold()) for k in fields]
    return hashlib.sha256(json.dumps(normalized, ensure_ascii=False).encode()).hexdigest()[:16]


def _run_extract(job: dict, pdf: Path, country: str) -> None:
    folder = WORK / "extract" / job["id"]
    folder.mkdir(parents=True, exist_ok=True)
    _set(job, status="running", stage="Reading PDF and locating curve and table pages")
    try:
        located = _locate(pdf)
        manifest = folder / "manifest.json"
        manifest.write_text(json.dumps({"papers": [{"pdf": str(pdf), "country": country}]},
                                       ensure_ascii=False), encoding="utf-8")
        _set(job, stage="Extracting candidate functions and parameters; preparing original-source evidence")
        env = os.environ.copy()
        deps = ROOT / ".local-deps"
        env["PYTHONPATH"] = str(deps) + os.pathsep + env.get("PYTHONPATH", "")
        process = subprocess.run([sys.executable, str(BACKEND), "run", "--manifest",
                                  str(manifest), "--out", str(folder)],
                                 cwd=ROOT, env=env, capture_output=True, text=True,
                                 encoding="utf-8", errors="replace", timeout=240)
        if process.returncode:
            raise RuntimeError((process.stderr or process.stdout)[-1200:])
        rows = json.loads((folder / "records.json").read_text(encoding="utf-8"))
        seen: dict[str, int] = {}
        candidates = []
        for idx, row in enumerate(rows):
            computable = bool(row.get("Function_Expression")) and any(
                str(row.get(k, "")).strip() for k in "abcde")
            key = _key(row) if computable else ""
            duplicate = seen.get(key) if key else None
            if key and duplicate is None:
                seen[key] = idx
            candidates.append({"index": idx, "country": row.get("Country", ""),
                               "building": row.get("Building_Type", ""),
                               "damage": row.get("Damage_State", ""),
                               "function": row.get("Function_Expression", ""),
                               "parameters": {k: row.get(k, "") for k in "abcde"},
                               "source": row.get("Source", ""),
                               "notes": _safe_snippet(row.get("Notes", ""), 500),
                               "duplicate_of": duplicate, "computable": computable,
                               "review_status": "Pending source verification"})
        with (folder / "parameter_candidates.csv").open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, FIELDS)
            writer.writeheader()
            writer.writerows([{k: r.get(k, "") for k in FIELDS} for r in rows])
        (folder / "review_decisions.json").write_text("[]", encoding="utf-8")
        result = {"pdf": str(pdf), "located_pages": located,
                  "candidate_count": len(rows), "unique_count": len(seen),
                  "extraction_mode": "document-specific table parser" if pdf.name.lower() in _scoped_names() else "candidate-page localization",
                  "candidates": candidates, "folder": str(folder),
                  "console": _safe_snippet(process.stdout, 800)}
        _set(job, status="complete", stage="Candidate function records generated; human source verification pending", result=result)
    except Exception as exc:
        _set(job, status="failed", stage="PDF-based function extraction failed", error=_safe_snippet(str(exc), 1000))


def review(job_id: str, index: int, status: str, note: str) -> dict:
    with LOCK:
        job = JOBS.get(job_id)
        if not job or job["kind"] != "extract" or job["status"] != "complete":
            raise ValueError("No completed extraction job was found.")
        candidates = job["result"]["candidates"]
        if not 0 <= index < len(candidates):
            raise ValueError("The candidate index is invalid.")
        if status not in {"Source verified", "Rejected"} or len(note.strip()) < 8:
            raise ValueError("Select a verification outcome and enter at least 8 characters of source evidence or an exclusion reason.")
        candidate = candidates[index]
        if status == "Source verified" and (candidate["duplicate_of"] is not None or
                                        not candidate["function"] or
                                        not any(str(v).strip() for v in candidate["parameters"].values())):
            raise ValueError("A duplicate or a candidate without a computable expression and parameters cannot be verified.")
        candidate["review_status"] = status
        candidate["review_note"] = note.strip()[:2000]
        folder = Path(job["result"]["folder"])
        (folder / "review_decisions.json").write_text(json.dumps(
            [{"index": c["index"], "status": c["review_status"], "note": c.get("review_note", "")}
             for c in candidates], ensure_ascii=False, indent=2), encoding="utf-8")
        return dict(candidate)


def file_for(job_id: str, kind: str) -> Path | None:
    job = get_job(job_id)
    if not job or job["status"] != "complete":
        return None
    folder = Path(job["result"]["folder"])
    if kind == "queries" and job["kind"] == "search":
        return folder / "search_queries.csv"
    if kind == "downloads" and job["kind"] == "search":
        return folder / "downloads.csv"
    if kind == "report" and job["kind"] == "search":
        return folder / "report.md"
    if kind == "parameters" and job["kind"] == "extract":
        return folder / "parameter_candidates.csv"
    if kind == "review" and job["kind"] == "extract":
        return folder / "review_decisions.json"
    if kind == "packet" and job["kind"] == "extract":
        return next(folder.glob("*_review.docx"), None)
    if kind == "checks" and job["kind"] == "extract":
        return folder / "curve_checks.json"
    return None


def _scoped_names() -> set[str]:
    # This list mirrors the named extractors bundled with fragility_pipeline.py.
    return {"buildings-13-01361.pdf", "nhess-2018-254.pdf", "nhess-2022-73-manuscript-version2.pdf",
            "9. seismic vulnerability assessment of hospital building.pdf", "10.2478_cee-2023-0039.pdf",
            "jurnal+no.14.pdf", "giordano2020_article_empiricalseismicfragilitymodel.pdf",
            "essd-2024-363.pdf", "wcee2000_2451yamaguchi.pdf", "adminasce,+360-364.pdf",
            "eas2201003.pdf", "wcee2024-miyamoto-haiti-fragility.pdf", "report07-18.pdf",
            "6_bnzsee1718_raheem+et+al_fragility+of+masonry+infilled+frames_with+supplementary+data.pdf",
            "doi_ 10.22034_22.2.16.pdf", "seismic+fragility.pdf", "a lovon_tarque_2018.pdf",
            "nhess-22-3211-2022.pdf", "6035-article text-31620-1-10-20250502.pdf",
            "53_2023_ijdrr_90_103610.pdf", "2019pcee_yamazaki.pdf"}
