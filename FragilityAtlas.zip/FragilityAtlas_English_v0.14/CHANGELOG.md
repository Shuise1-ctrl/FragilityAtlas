# Changelog

## v0.14 English UI correction — 2026-11-23

- Replaced the upper-left brand with `FragilityAtlas`.
- Replaced the locale-dependent native PDF picker text with an English `Choose PDF` control and `No file selected` status. The original file upload remains functional.
- Corrected remaining Chinese display text in the source-specific damage and building descriptions without changing the underlying database records.
- Verified all four navigation pages, the local server workflow, and direct-file read-only browsing.

## English localization of local service v0.14 (2026-11-23)

- Restored direct `file://` opening with a bundled offline data script. The first three pages, filtering, plotting, navigation, and exports now work when `out/index.html` is opened without a server.
- Reduced English UI type sizes, wrapped long navigation labels, and removed the requested sidebar status/version copy and header badge/avatar.
- Added English interface labels, help, filters, Agent messages, and export labels across four pages.
- Added English source-specific damage descriptions and existing English building labels in the presentation layer; the published JSON snapshot and pairing ledger are byte-identical to the Chinese source backup.
- Removed a machine-specific private configuration fallback and made the runtime database path relative to the release directory.
- Added portable launch documentation, terminology, and release validation reports.

This is a localization of the supplied v0.14 runtime. It does not claim a new scientific database version or change extraction algorithms.
