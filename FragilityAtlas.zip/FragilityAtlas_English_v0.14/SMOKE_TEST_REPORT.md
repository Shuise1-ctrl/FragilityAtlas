# Smoke-test report

Date: 2026-11-23. Local test host: Windows, Python 3.12.3, FastAPI 0.141.1, Uvicorn 0.51.0, python-docx 1.2.0, Selenium 4.29.0. PDF smoke-test dependencies `pypdf 7.1.1` and `pypdfium2 5.15.2` were installed into an **external test-only directory**; that directory is not bundled. The released `requirements.txt` declares minimum versions, not a lockfile.

## Passed

| Check | Observed result |
|---|---|
| Local service startup | Uvicorn started on loopback port 8877 for an isolated test; documented default in `server.py` is 8876. |
| Health endpoint | `/api/health` returned application version `0.14`, `source_available: true`, `pdf_ready: true`, and `search_ready: false` with no configured key. |
| Published snapshot load | `/api/curves` returned 2,018 applicability records and 32 sources; dataset statistics report 1,820 deduplicated curves and 585 groups. |
| Four browser pages | Basic Information, Fragility Database, Japan Classic Curves, and Literature Agent Workbench opened without browser JavaScript errors under the local service. |
| Direct-file opening | In Edge, opening `out/index.html` through `file://` loaded 2,018 records, 15 country cards, the database and 24 Japan chart cards. All four sidebar links switched views; the Agent page correctly stated that it needs the local service. No browser JavaScript errors occurred. |
| Direct-file filters and exports | Japan filtering returned 304 applicability records / 298 curves; a selected curve drew eight SVG paths. CSV, JSON, and Japan SVG downloads succeeded from `file://`. |
| Layout and requested removals | A 1440 × 900 browser capture showed wrapped navigation without overlap and more compact text. The sidebar loading/status/version copy, header badge, and `FA` avatar were absent. |
| Country and IM filtering | Selecting United States returned 1,032 applicability records / 949 curves and only PGA in the IM menu; Japan returned 304 / 298. |
| Curve calculation and plotting | The selected Japan curve dialog rendered eight SVG path elements and showed the original publication title and DOI. |
| Browser exports | Function CSV, database JSON, and a Japan SVG were downloaded. The SVG contained a DOI line and no Chinese UI text. CSV field names are English schema keys. |
| Static read-only hosting | A separate static HTTP server loaded Basic Information, the database, and 24 Japan curve cards. The Agent page displayed its local-service requirement without a JavaScript error. |
| PDF upload and candidate generation | A 1,610-byte synthetic PDF uploaded; page localization found one relevant page; the existing local pipeline produced one **non-computable candidate** with blank parameters. The 17-column CSV, review DOCX, validation JSON, and review JSON were generated. |
| Source-verification guard | The test candidate was explicitly marked `Rejected`; it was not published as a verified function. |
| Published database isolation | SHA-256 values of the five public JSON files were unchanged by the Agent upload/extraction test. |
| Language audit | 15 country-filtered database views, the curve dialog, all Japan IM views, and Agent controls were scanned. Remaining Chinese/Japanese text was source metadata/original codes, not UI labels. |
| Secret/path scan | No key-like value or local absolute path remained in the draft release tree after public-path redaction. |

## Not tested / limits

- **Online Agent search and PDF download: not tested.** DeepSeek API key and the configured search service were unavailable; no successful online retrieval is claimed.
- **Extraction accuracy: not tested.** The synthetic PDF only verifies the upload/localization/candidate path. It does not establish document-specific or general parameter accuracy.
- **Public GitHub deployment: not tested.** The repository URL and license require maintainer completion.
- **Publisher-authenticated full text: not supported by the supplied code.**

No silent test failures were reclassified as passes. A first review call failed after a temporary test job folder was intentionally removed; a fresh upload/extraction job then completed and the `Rejected` decision succeeded. Only the latter result supports the verification-guard pass above.
