"""Integrated loopback service: static browser client + read-only research APIs."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / '.local-deps'))
import json
import threading
import urllib.request
import urllib.parse
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import agent_workflow as agent

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'out' / 'curves.json'
app = FastAPI(title='FragilityAtlas local service', docs_url='/api/docs')
refresh_lock = threading.Lock()

@app.middleware('http')
async def local_requests(request: Request, call_next):
    # Do not expose local PDFs or operations to arbitrary origins / DNS rebinding.
    host = request.headers.get('host','').split(':')[0]
    if host not in {'127.0.0.1','localhost'}:
        return JSONResponse({'detail':'Local hosts only'},status_code=403)
    origin = request.headers.get('origin')
    if origin and origin != 'http://' + request.headers.get('host',''):
        return JSONResponse({'detail':'Cross-origin access is disabled'},status_code=403)
    response = await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    return response

@app.get('/api/health')
def health():
    return {'service':'fragility-local','version':'0.14','source_available':BASE.exists(),'data_scope':'verified-paper-table-only','agent':agent.readiness()}

def _same_origin(request: Request):
    if request.headers.get('origin') != 'http://' + request.headers.get('host',''):
        raise HTTPException(403,'Agent operations must originate from this local browser session.')

@app.get('/api/agent/readiness')
def agent_readiness():
    return agent.readiness()

@app.get('/api/agent/jobs')
def agent_jobs():
    return {'jobs':agent.list_jobs()}

@app.get('/api/agent/jobs/{job_id}')
def agent_job(job_id: str):
    job=agent.get_job(job_id)
    if not job: raise HTTPException(404,'Job not found, or the local service has restarted.')
    return job

@app.post('/api/agent/search')
async def agent_search(request: Request):
    _same_origin(request)
    data=await request.json()
    try:return agent.start_search(str(data.get('country','')),str(data.get('building','')),str(data.get('im','')),
                                  str(data.get('deepseek_api_key','')),str(data.get('serper_api_key','')))
    except ValueError as e:raise HTTPException(400,str(e))

@app.post('/api/agent/upload')
async def agent_upload(request: Request):
    _same_origin(request)
    length=int(request.headers.get('content-length','0'))
    if not 0<length<=50*1024*1024:raise HTTPException(413,'The PDF must be smaller than 50 MB.')
    name=urllib.parse.unquote(request.headers.get('x-filename','paper.pdf'))
    try:return agent.save_upload(name,await request.body())
    except ValueError as e:raise HTTPException(400,str(e))

@app.post('/api/agent/extract')
async def agent_extract(request: Request):
    _same_origin(request)
    data=await request.json()
    try:return agent.start_extract(str(data.get('path','')),str(data.get('country','')))
    except ValueError as e:raise HTTPException(400,str(e))

@app.post('/api/agent/jobs/{job_id}/review')
async def agent_review(job_id: str,request: Request):
    _same_origin(request)
    data=await request.json()
    try:return agent.review(job_id,int(data.get('index',-1)),str(data.get('status','')),str(data.get('note','')))
    except (ValueError,TypeError) as e:raise HTTPException(400,str(e))

@app.get('/api/agent/jobs/{job_id}/file/{kind}')
def agent_file(job_id: str,kind: str):
    path=agent.file_for(job_id,kind)
    if not path or not path.is_file():raise HTTPException(404,'The job file is not available yet.')
    return FileResponse(path,filename=path.name)

@app.get('/api/agent/jobs/{job_id}/source.pdf')
def agent_source_pdf(job_id: str):
    job=agent.get_job(job_id)
    if not job or job['kind']!='extract' or job['status']!='complete':
        raise HTTPException(404,'The original PDF is not available yet.')
    path=Path(job['result']['pdf'])
    if not path.is_file():raise HTTPException(404,'The original PDF has moved.')
    return FileResponse(path,media_type='application/pdf',content_disposition_type='inline')

@app.get('/api/curves')
def curves():
    folder=ROOT/'out'
    data=json.loads((folder/'curves.json').read_text(encoding='utf-8'))
    data['records']=[row for name in data['record_chunks'] for row in json.loads((folder/name).read_text(encoding='utf-8'))]
    return data

@app.post('/api/curves/refresh')
def refresh_curves(request: Request):
    raise HTTPException(409,'This is a frozen, source-paired snapshot. Rebuilding requires a separately verified source-data workflow.')

@app.get('/api/snapshot')
def snapshot():
    raise HTTPException(404,'This release provides the source-paired Fragility Database only.')

@app.post('/api/refresh')
def refresh(request: Request):
    raise HTTPException(409,'Unverified literature cannot be imported into the published database.')

@app.get('/api/documents/{doc_id}/pdf')
def pdf(doc_id: str):
    raise HTTPException(404,'Original source PDFs are not distributed with this release.')

@app.get('/api/search')
def search(q: str):
    if not 2 <= len(q) <= 700:
        raise HTTPException(400,'The search query must contain 2–700 characters.')
    url='https://api.crossref.org/works?'+urllib.parse.urlencode({'query':q,'rows':12,'select':'DOI,title,publisher,published'})
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'FragilityAtlasPrototype/0.1'})
        with urllib.request.urlopen(req,timeout=25) as response:
            items=json.load(response)['message']['items']
        return {'items':[{'title':(d.get('title') or ['Untitled'])[0], 'doi':d.get('DOI',''), 'publisher':d.get('publisher',''), 'year':d.get('published',{}).get('date-parts',[['']])[0][0]} for d in items]}
    except Exception:
        raise HTTPException(502,'Crossref is unavailable. Please try again later.')

app.mount('/',StaticFiles(directory=ROOT/'out',html=True),name='client')

if __name__=='__main__':
    import uvicorn
    uvicorn.run(app,host='127.0.0.1',port=8876)


