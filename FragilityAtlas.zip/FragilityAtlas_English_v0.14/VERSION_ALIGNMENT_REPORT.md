# Version alignment report

| Item | Observed value | Action |
|---|---|---|
| Local service `/api/health` and current application source | `0.14` | English draft package is labeled `v0.14`; this is an application/runtime version. |
| Published JSON `out/curves.json` | `0.12`, generated `2026-11-22T09:29:27.548956+08:00` | Keep the source dataset version distinct from the application version. |
| Manuscript Software Metadata C1 | `V1` | Maintainer must decide and update the manuscript to the version of the submitted code archive, e.g. `v0.14`, or explain a separate formal release scheme. |
| Manuscript Metadata C2, C6, C7 | `https://github.com/Shuise1-ctrl/xx` and derived README links | **To be completed by the maintainer:** replace with the actual public repository/permanent release URL after it exists. The placeholder must not be submitted as a working link. |
| License | Not supplied in local source | **To be completed by the maintainer:** choose and add the appropriate code/data license only after rights review. This package is a safe draft, not a licensed GitHub release. |
| Citation authors, year, article DOI, contact | Not supplied as final release metadata | **To be completed by the maintainer.** Do not infer these from the manuscript title or placeholder URL. |

No GitHub repository was pushed to or overwritten. The Chinese source and ZIP were not modified. The public-safe path redaction is documented in `ENGLISH_LOCALIZATION_REPORT.md`.
