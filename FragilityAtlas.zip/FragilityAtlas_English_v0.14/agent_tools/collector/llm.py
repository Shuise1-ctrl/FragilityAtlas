from __future__ import annotations

import json
from typing import Any

from .http import HttpError, JsonHttpClient


class LLMResponseError(RuntimeError):
    pass


class DeepSeekClient:
    def __init__(
        self,
        api_key: str,
        base_url: str,
        model: str,
        http: JsonHttpClient,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.http = http

    def json_completion(
        self,
        *,
        system: str,
        user: str,
        temperature: float = 0.1,
    ) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "response_format": {"type": "json_object"},
            "temperature": temperature,
            "stream": False,
        }
        try:
            response = self.http.request_json(
                f"{self.base_url}/chat/completions",
                method="POST",
                headers={"Authorization": f"Bearer {self.api_key}"},
                payload=payload,
            )
        except HttpError as exc:
            raise LLMResponseError(str(exc)) from exc

        try:
            content = response["choices"][0]["message"]["content"]
            parsed = json.loads(content)
        except (KeyError, IndexError, TypeError, json.JSONDecodeError) as exc:
            raise LLMResponseError(
                f"DeepSeek returned an invalid JSON response: {response!r}"
            ) from exc
        if not isinstance(parsed, dict):
            raise LLMResponseError("DeepSeek response must be a JSON object")
        return parsed
