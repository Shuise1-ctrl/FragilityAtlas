from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _load_env_file(path: Path = Path(".env")) -> None:
    if not path.is_file():
        return
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        name = name.strip()
        value = value.strip().strip("\"'")
        if name and name not in os.environ:
            os.environ[name] = value


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer, got {raw!r}") from exc


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    normalized = raw.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"{name} must be a boolean, got {raw!r}")


@dataclass(frozen=True)
class Settings:
    deepseek_api_key: str
    serper_api_key: str
    search_engine: str = "serper"
    kuntin_base_url: str = "http://kespro.kuntin.cn"
    kuntin_search_url: str = ""
    kuntin_login_timeout: int = 60
    kuntin_search_timeout: int = 30
    deepseek_base_url: str = "https://api.deepseek.com"
    deepseek_model: str = "deepseek-v4-flash"
    output_root: Path = Path("research_output")
    max_rounds: int = 3
    queries_per_round: int = 12
    results_per_query: int = 8
    max_pages: int = 30
    max_downloads: int = 20
    max_crawl_depth: int = 2
    links_per_page: int = 30
    max_file_bytes: int = 50 * 1024 * 1024
    request_timeout: int = 30
    llm_timeout: int = 90
    rating_batch_size: int = 8
    max_page_chars: int = 30_000
    max_document_chars: int = 80_000
    max_llm_material_chars: int = 80_000
    browser_enabled: bool = True
    browser_headless: bool = False
    browser_verify_timeout: int = 180
    browser_download_timeout: int = 120
    browser_profile_dir: Path = Path(".browser_profile")

    @classmethod
    def from_env(cls) -> "Settings":
        _load_env_file()
        return cls(
            deepseek_api_key=os.getenv("DEEPSEEK_API_KEY", "").strip(),
            serper_api_key=os.getenv("SERPER_API_KEY", "").strip(),
            search_engine=os.getenv("COLLECTOR_SEARCH_ENGINE", "serper").strip().lower(),
            kuntin_base_url=os.getenv(
                "KUNTIN_BASE_URL", "http://kespro.kuntin.cn"
            ).rstrip("/"),
            kuntin_search_url=os.getenv("KUNTIN_SEARCH_URL", "").strip(),
            kuntin_login_timeout=_env_int("KUNTIN_LOGIN_TIMEOUT", 60),
            kuntin_search_timeout=_env_int("KUNTIN_SEARCH_TIMEOUT", 30),
            deepseek_base_url=os.getenv(
                "DEEPSEEK_BASE_URL", "https://api.deepseek.com"
            ).rstrip("/"),
            deepseek_model=os.getenv(
                "DEEPSEEK_MODEL", "deepseek-v4-flash"
            ).strip(),
            output_root=Path(
                os.getenv("COLLECTOR_OUTPUT_DIR", "research_output")
            ),
            max_rounds=_env_int("COLLECTOR_MAX_ROUNDS", 3),
            queries_per_round=_env_int("COLLECTOR_QUERIES_PER_ROUND", 12),
            results_per_query=_env_int("COLLECTOR_RESULTS_PER_QUERY", 8),
            max_pages=_env_int("COLLECTOR_MAX_PAGES", 30),
            max_downloads=_env_int("COLLECTOR_MAX_DOWNLOADS", 20),
            max_crawl_depth=_env_int("COLLECTOR_MAX_CRAWL_DEPTH", 2),
            links_per_page=_env_int("COLLECTOR_LINKS_PER_PAGE", 30),
            max_file_bytes=_env_int(
                "COLLECTOR_MAX_FILE_BYTES", 50 * 1024 * 1024
            ),
            request_timeout=_env_int("COLLECTOR_REQUEST_TIMEOUT", 30),
            llm_timeout=_env_int("COLLECTOR_LLM_TIMEOUT", 90),
            rating_batch_size=_env_int("COLLECTOR_RATING_BATCH_SIZE", 8),
            max_page_chars=_env_int("COLLECTOR_MAX_PAGE_CHARS", 30_000),
            max_document_chars=_env_int(
                "COLLECTOR_MAX_DOCUMENT_CHARS", 80_000
            ),
            max_llm_material_chars=_env_int(
                "COLLECTOR_MAX_LLM_MATERIAL_CHARS", 80_000
            ),
            browser_enabled=_env_bool("COLLECTOR_BROWSER_ENABLED", True),
            browser_headless=_env_bool("COLLECTOR_BROWSER_HEADLESS", False),
            browser_verify_timeout=_env_int(
                "COLLECTOR_BROWSER_VERIFY_TIMEOUT", 180
            ),
            browser_download_timeout=_env_int(
                "COLLECTOR_BROWSER_DOWNLOAD_TIMEOUT", 120
            ),
            browser_profile_dir=Path(
                os.getenv("COLLECTOR_BROWSER_PROFILE_DIR", ".browser_profile")
            ),
        )

    def validate(self) -> None:
        if self.search_engine not in {"serper", "kuntin", "both"}:
            raise ValueError(
                "COLLECTOR_SEARCH_ENGINE must be one of: serper, kuntin, both"
            )
        if not self.deepseek_api_key:
            raise ValueError("DEEPSEEK_API_KEY is required")
        if len(self.deepseek_api_key) < 20:
            raise ValueError(
                "DEEPSEEK_API_KEY appears incomplete. "
                "Run setup_config.bat and enter the full API key."
            )
        if self.search_engine in {"serper", "both"}:
            if not self.serper_api_key:
                raise ValueError(
                    "SERPER_API_KEY is required when COLLECTOR_SEARCH_ENGINE is serper or both"
                )
            if len(self.serper_api_key) < 20:
                raise ValueError(
                    "SERPER_API_KEY appears incomplete. "
                    "Run setup_config.bat and enter the full API key."
                )
        positive = {
            "max_rounds": self.max_rounds,
            "queries_per_round": self.queries_per_round,
            "results_per_query": self.results_per_query,
            "max_pages": self.max_pages,
            "max_downloads": self.max_downloads,
            "links_per_page": self.links_per_page,
            "max_file_bytes": self.max_file_bytes,
            "request_timeout": self.request_timeout,
            "llm_timeout": self.llm_timeout,
            "rating_batch_size": self.rating_batch_size,
            "max_llm_material_chars": self.max_llm_material_chars,
            "browser_verify_timeout": self.browser_verify_timeout,
            "browser_download_timeout": self.browser_download_timeout,
            "kuntin_login_timeout": self.kuntin_login_timeout,
            "kuntin_search_timeout": self.kuntin_search_timeout,
        }
        invalid = [name for name, value in positive.items() if value <= 0]
        if invalid:
            raise ValueError(f"Settings must be positive: {', '.join(invalid)}")
        if self.max_crawl_depth < 0:
            raise ValueError("max_crawl_depth cannot be negative")
