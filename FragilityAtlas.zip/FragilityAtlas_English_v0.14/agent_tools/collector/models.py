from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class SearchResult:
    query: str
    url: str
    title: str = ""
    snippet: str = ""
    published_date: str = "Unknown"
    publisher: str = "Unknown"
    relevance_score: int = 0
    authority_score: int = 0
    recency_score: int = 0
    recommendation_score: int = 0
    stars: int = 0
    recommendation_reason: str = ""
    file_path: str = ""
    download_success: str = ""


@dataclass
class PageRecord:
    url: str
    title: str = ""
    text: str = ""
    links: list[dict[str, Any]] = field(default_factory=list)
    error: str | None = None
    depth: int = 0
    parent_url: str | None = None


@dataclass
class FileRecord:
    source_url: str
    local_path: str
    content_type: str = ""
    sha256: str = ""
    size: int = 0
    parsed_text: str = ""
    parse_error: str | None = None


@dataclass
class DownloadRecord:
    url: str
    source_page: str | None = None
    title: str = ""
    status: str = "pending"
    reason: str = ""
    local_path: str | None = None
    content_type: str = ""
    sha256: str = ""
    size: int = 0
    published_date: str = "Unknown"
    publisher: str = "Unknown"
    relevance_score: int = 0
    authority_score: int = 0
    recency_score: int = 0
    recommendation_score: int = 0
    stars: int = 0
    recommendation_reason: str = ""


@dataclass
class Evidence:
    claim: str
    source_url: str
    support: str
    local_file: str | None = None
    page_number: int | None = None
    confidence: float = 0.5


@dataclass
class ResearchState:
    task_id: str
    objective: str
    questions: list[str] = field(default_factory=list)
    queries: list[str] = field(default_factory=list)
    search_results: list[SearchResult] = field(default_factory=list)
    pages: list[PageRecord] = field(default_factory=list)
    files: list[FileRecord] = field(default_factory=list)
    downloads: list[DownloadRecord] = field(default_factory=list)
    evidence: list[Evidence] = field(default_factory=list)
    missing_information: list[str] = field(default_factory=list)
    round_number: int = 0

    @property
    def visited_urls(self) -> set[str]:
        return {page.url for page in self.pages}

    @property
    def downloaded_urls(self) -> set[str]:
        return {item.source_url for item in self.files}

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
