from __future__ import annotations

import csv
import json
from pathlib import Path


class DocumentParser:
    def __init__(self, max_chars: int = 80_000) -> None:
        self.max_chars = max_chars
        self._converter = None
        self._docling_error: Exception | None = None

    def parse(self, path: Path) -> str:
        suffix = path.suffix.lower()
        if suffix in {".txt", ".md", ".html", ".htm", ".json"}:
            return path.read_text(encoding="utf-8", errors="replace")[
                : self.max_chars
            ]
        if suffix == ".csv":
            return self._parse_csv(path)
        if suffix in {".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx"}:
            try:
                return self._parse_docling(path)
            except Exception as docling_error:
                try:
                    return self._parse_fallback(path)
                except Exception as fallback_error:
                    raise RuntimeError(
                        f"Docling failed: {docling_error}; "
                        f"fallback parser failed: {fallback_error}"
                    ) from fallback_error
        raise ValueError(f"Unsupported document type: {suffix or '<none>'}")

    def _parse_csv(self, path: Path) -> str:
        rows: list[list[str]] = []
        with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
            for index, row in enumerate(csv.reader(handle)):
                rows.append(row)
                if index >= 999:
                    break
        return json.dumps(rows, ensure_ascii=False)[: self.max_chars]

    def _parse_docling(self, path: Path) -> str:
        if self._docling_error is not None:
            raise RuntimeError(
                f"Docling is unavailable in this process: {self._docling_error}"
            )
        try:
            from docling.document_converter import DocumentConverter
            if self._converter is None:
                self._converter = DocumentConverter()
            result = self._converter.convert(path)
            return result.document.export_to_markdown()[: self.max_chars]
        except Exception as exc:
            self._docling_error = exc
            raise

    def _parse_fallback(self, path: Path) -> str:
        suffix = path.suffix.lower()
        if suffix == ".pdf":
            return self._parse_pdf(path)
        if suffix == ".docx":
            return self._parse_docx(path)
        if suffix == ".xlsx":
            return self._parse_xlsx(path)
        if suffix == ".pptx":
            return self._parse_pptx(path)
        raise RuntimeError(f"No fallback parser is available for {suffix}")

    def _parse_pdf(self, path: Path) -> str:
        try:
            import fitz
        except ImportError as exc:
            raise RuntimeError("Install PyMuPDF to use the PDF fallback") from exc
        parts: list[str] = []
        current_length = 0
        with fitz.open(path) as document:
            for page_number, page in enumerate(document, start=1):
                text = page.get_text("text").strip()
                section = f"\n\n## Page {page_number}\n\n{text}"
                parts.append(section)
                current_length += len(section)
                if current_length >= self.max_chars:
                    break
        return "".join(parts)[: self.max_chars]

    def _parse_docx(self, path: Path) -> str:
        try:
            from docx import Document
        except ImportError as exc:
            raise RuntimeError("Install python-docx to use the DOCX fallback") from exc
        document = Document(path)
        parts = [paragraph.text for paragraph in document.paragraphs if paragraph.text]
        for table in document.tables:
            for row in table.rows:
                parts.append(" | ".join(cell.text for cell in row.cells))
        return "\n".join(parts)[: self.max_chars]

    def _parse_xlsx(self, path: Path) -> str:
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise RuntimeError("Install openpyxl to use the XLSX fallback") from exc
        workbook = load_workbook(path, read_only=True, data_only=True)
        parts: list[str] = []
        current_length = 0
        try:
            for worksheet in workbook.worksheets:
                parts.append(f"\n\n## Sheet: {worksheet.title}\n")
                for row in worksheet.iter_rows(values_only=True):
                    line = " | ".join("" if value is None else str(value) for value in row)
                    parts.append(line)
                    current_length += len(line) + 1
                    if current_length >= self.max_chars:
                        return "\n".join(parts)[: self.max_chars]
        finally:
            workbook.close()
        return "\n".join(parts)[: self.max_chars]

    def _parse_pptx(self, path: Path) -> str:
        try:
            from pptx import Presentation
        except ImportError as exc:
            raise RuntimeError("Install python-pptx to use the PPTX fallback") from exc
        presentation = Presentation(path)
        parts: list[str] = []
        current_length = 0
        for slide_number, slide in enumerate(presentation.slides, start=1):
            heading = f"\n\n## Slide {slide_number}\n"
            parts.append(heading)
            current_length += len(heading)
            for shape in slide.shapes:
                text = getattr(shape, "text", "")
                if text:
                    parts.append(text)
                    current_length += len(text)
            if current_length >= self.max_chars:
                break
        return "\n".join(parts)[: self.max_chars]
