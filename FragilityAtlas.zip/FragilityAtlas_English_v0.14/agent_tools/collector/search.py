from __future__ import annotations

import getpass
import time
from pathlib import Path
from urllib.parse import urljoin

from .http import JsonHttpClient
from .models import SearchResult


class SerperSearchClient:
    endpoint = "https://google.serper.dev/search"

    def __init__(self, api_key: str, http: JsonHttpClient) -> None:
        self.api_key = api_key
        self.http = http

    def search(self, query: str, limit: int) -> list[SearchResult]:
        data = self.http.request_json(
            self.endpoint,
            method="POST",
            headers={"X-API-KEY": self.api_key},
            payload={"q": query, "num": limit},
        )
        results: list[SearchResult] = []
        for item in data.get("organic", []):
            if not isinstance(item, dict):
                continue
            url = str(item.get("link", "")).strip()
            if not url.startswith(("http://", "https://")):
                continue
            results.append(
                SearchResult(
                    query=query,
                    url=url,
                    title=str(item.get("title", "")),
                    snippet=str(item.get("snippet", "")),
                    published_date=str(item.get("date") or "Unknown"),
                    publisher=str(item.get("source") or "Unknown"),
                )
            )
        return results


class KuntinSearchError(RuntimeError):
    """Raised when the Kuntin site cannot be searched."""


class KuntinSearchClient:
    """Search Kuntin through its authenticated, rendered website in Edge."""

    def __init__(
        self,
        base_url: str,
        *,
        search_url: str = "",
        profile_dir: Path = Path(".browser_profile"),
        login_timeout: int = 60,
        search_timeout: int = 30,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.search_url = search_url or self.base_url
        self.profile_dir = profile_dir
        self.login_timeout = login_timeout
        self.search_timeout = search_timeout
        self._driver = None
        self._username = ""
        self._password = ""

    def search(self, query: str, limit: int) -> list[SearchResult]:
        driver = self._get_driver()
        self._login_if_needed(driver)
        driver.get(self.search_url)
        search_box = self._find_search_box(driver)
        if search_box is None:
            raise KuntinSearchError(
                "Signed in to kespro.kuntin.cn, but no site-search field was found."
                "Inspect the page or set KUNTIN_SEARCH_URL in .env."
            )

        from selenium.webdriver.common.keys import Keys

        search_box.clear()
        search_box.send_keys(query)
        search_box.send_keys(Keys.ENTER)
        time.sleep(1)
        self._wait_for_results(driver)
        return self._extract_results(driver, query, limit)

    def close(self) -> None:
        if self._driver is not None:
            try:
                self._driver.quit()
            finally:
                self._driver = None
                self._username = ""
                self._password = ""

    def _get_driver(self):
        if self._driver is not None:
            return self._driver
        try:
            from selenium import webdriver
            from selenium.webdriver.edge.options import Options
        except ImportError as exc:
            raise KuntinSearchError(
                "Kuntin site search requires Selenium. Run "
                "python -m pip install -r requirements.txt"
            ) from exc

        profile = self.profile_dir.resolve() / "kuntin_search"
        profile.mkdir(parents=True, exist_ok=True)
        options = Options()
        options.add_argument("--disable-popup-blocking")
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        options.add_argument(f"--user-data-dir={profile}")
        try:
            self._driver = webdriver.Edge(options=options)
            self._driver.set_page_load_timeout(
                max(self.login_timeout, self.search_timeout)
            )
            return self._driver
        except Exception as exc:
            raise KuntinSearchError(f"Could not start the Kuntin search browser: {exc}") from exc

    def _login_if_needed(self, driver) -> None:
        driver.get(self.base_url)
        if not self._is_login_page(driver):
            return

        if not self._username:
            self._username = input(
                "Enter the kespro.kuntin.cn username, email address, or phone number: "
            ).strip()
        if not self._password:
            self._password = getpass.getpass(
                "Enter the kespro.kuntin.cn password (input is hidden): "
            )
        if not self._username or not self._password:
            raise KuntinSearchError("Kuntin username and password cannot be empty.")

        try:
            driver.find_element("css selector", "#usernameOrEmailAddress").send_keys(
                self._username
            )
            driver.find_element("css selector", "#Password").send_keys(
                self._password
            )
            driver.find_element("css selector", "#LoginButton").click()
        except Exception as exc:
            raise KuntinSearchError(f"Could not submit the Kuntin sign-in form: {exc}") from exc

        deadline = time.monotonic() + self.login_timeout
        while time.monotonic() < deadline:
            if not self._is_login_page(driver):
                return
            time.sleep(1)
        raise KuntinSearchError(
            "Kuntin sign-in was not completed. Check credentials or any additional verification required by the site."
        )

    @staticmethod
    def _is_login_page(driver) -> bool:
        try:
            return (
                "/account/login" in driver.current_url.lower()
                and bool(
                    driver.find_elements(
                        "css selector", "#usernameOrEmailAddress, #Password"
                    )
                )
            )
        except Exception:
            return False

    @staticmethod
    def _find_search_box(driver):
        selectors = (
            "input[type='search']",
            "input[name*='search' i]",
            "input[id*='search' i]",
            "input[placeholder*='搜索']",
            "input[placeholder*='检索']",
            "input[placeholder*='Search' i]",
            ".txt-search input",
            ".txt-search",
            "textarea[name*='search' i]",
        )
        for selector in selectors:
            for element in driver.find_elements("css selector", selector):
                if element.is_displayed() and element.is_enabled():
                    return element
        return None

    def _wait_for_results(self, driver) -> None:
        deadline = time.monotonic() + self.search_timeout
        while time.monotonic() < deadline:
            if self._visible_links(driver):
                return
            time.sleep(0.5)

    @staticmethod
    def _visible_links(driver):
        return [
            link
            for link in driver.find_elements("css selector", "a[href]")
            if link.is_displayed()
        ]

    def _extract_results(
        self, driver, query: str, limit: int
    ) -> list[SearchResult]:
        results: list[SearchResult] = []
        seen: set[str] = set()
        for link in self._visible_links(driver):
            href = (link.get_attribute("href") or "").strip()
            if not href:
                continue
            href = urljoin(driver.current_url, href)
            lower = href.lower()
            if href in seen or lower.startswith(("javascript:", "mailto:")):
                continue
            if any(part in lower for part in ("/account/login", "/logout", "/home/index")):
                continue
            title = (link.text or link.get_attribute("title") or "").strip()
            if not title:
                continue
            seen.add(href)
            try:
                snippet = " ".join(link.find_element("xpath", "..").text.split())
            except Exception:
                snippet = ""
            results.append(
                SearchResult(
                    query=query,
                    url=href,
                    title=title[:500],
                    snippet=snippet[:2000],
                    published_date="Unknown",
                    publisher="Kuntin network resource-sharing service",
                )
            )
            if len(results) >= limit:
                break
        return results


class SearchEngineRouter:
    """Route searches to Serper, Kuntin, or both, deduplicating URLs."""

    def __init__(self, clients: list[object], *, tolerate_partial: bool = False) -> None:
        self.clients = clients
        self.tolerate_partial = tolerate_partial

    def search(self, query: str, limit: int) -> list[SearchResult]:
        results: list[SearchResult] = []
        errors: list[str] = []
        seen: set[str] = set()
        for client in self.clients:
            try:
                found = client.search(query, limit)
            except Exception as exc:
                if not self.tolerate_partial:
                    raise
                errors.append(str(exc))
                continue
            for item in found:
                if item.url not in seen:
                    seen.add(item.url)
                    results.append(item)
        if errors:
            print("[search-provider notice] " + "；".join(errors))
        if not results and errors:
            raise RuntimeError("All selected search providers failed: " + "；".join(errors))
        return results[:limit * len(self.clients)]

    def close(self) -> None:
        for client in self.clients:
            close = getattr(client, "close", None)
            if callable(close):
                close()
