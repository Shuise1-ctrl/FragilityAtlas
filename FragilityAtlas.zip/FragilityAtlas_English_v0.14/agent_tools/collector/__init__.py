"""Lightweight, controllable DeepSeek research collector."""

from .config import Settings
from .pipeline import ResearchPipeline

__all__ = ["ResearchPipeline", "Settings"]
