from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable

from .models import ResearchState


class ResearchStore:
    """Write human-readable UTF-8 CSV files for the current task state."""

    def __init__(self, task_dir: Path) -> None:
        self.task_dir = task_dir
        self.task_dir.mkdir(parents=True, exist_ok=True)

    def save(self, state: ResearchState) -> None:
        self._write_csv(
            "search_queries.csv",
            ["Index", "Search_Query"],
            [
                [index, query]
                for index, query in enumerate(state.queries, start=1)
            ],
        )
        self._write_csv(
            "search_results.csv",
            [
                "Index",
                "Recommendation_Stars",
                "Overall_Score",
                "Relevance_Score",
                "Source_Authority_Score",
                "Recency_Score",
                "Publication_Date",
                "Publisher",
                "Recommendation_Reason",
                "Search_Query",
                "Title",
                "URL",
                "Snippet",
                "Likely_File",
                "Local_File",
                "Download_Outcome",
            ],
            [
                [
                    index,
                    "★" * item.stars,
                    item.recommendation_score,
                    item.relevance_score,
                    item.authority_score,
                    item.recency_score,
                    item.published_date,
                    item.publisher,
                    item.recommendation_reason,
                    item.query,
                    item.title,
                    item.url,
                    item.snippet,
                    "Yes" if self._looks_like_file_result(item.url, item.title) else "No",
                    item.file_path,
                    item.download_success,
                ]
                for index, item in enumerate(
                    sorted(
                        state.search_results,
                        key=lambda item: (
                            item.stars,
                            item.recommendation_score,
                            item.relevance_score,
                            item.authority_score,
                            item.recency_score,
                        ),
                        reverse=True,
                    ),
                    start=1,
                )
            ],
        )
        self._write_csv(
            "pages.csv",
            [
                "Index",
                "Crawl_Depth",
                "Title",
                "URL",
                "Parent_Page",
                "Discovered_Links",
                "Visit_Status",
                "Error",
            ],
            [
                [
                    index,
                    item.depth,
                    item.title,
                    item.url,
                    item.parent_url or "",
                    len(item.links),
                    "Failed" if item.error else "Succeeded",
                    item.error or "",
                ]
                for index, item in enumerate(state.pages, start=1)
            ],
        )
        self._write_csv(
            "downloads.csv",
            [
                "Index",
                "Recommendation_Stars",
                "Overall_Score",
                "Relevance_Score",
                "Source_Authority_Score",
                "Recency_Score",
                "Publication_Date",
                "Publisher",
                "Recommendation_Reason",
                "Title",
                "URL",
                "Source_Page",
                "Status",
                "Reason",
                "Local_File",
                "Content_Type",
                "File_Size_Bytes",
                "SHA256",
            ],
            [
                [
                    index,
                    "★" * item.stars,
                    item.recommendation_score,
                    item.relevance_score,
                    item.authority_score,
                    item.recency_score,
                    item.published_date,
                    item.publisher,
                    item.recommendation_reason,
                    item.title,
                    item.url,
                    item.source_page or "",
                    item.status,
                    item.reason,
                    item.local_path or "",
                    item.content_type,
                    item.size,
                    item.sha256,
                ]
                for index, item in enumerate(state.downloads, start=1)
            ],
        )

    def write_report(self, markdown: str) -> Path:
        report = self.task_dir / "report.md"
        report.write_text(markdown, encoding="utf-8-sig")
        return report

    def _write_csv(
        self,
        filename: str,
        headers: list[str],
        rows: Iterable[list[object]],
    ) -> None:
        path = self.task_dir / filename
        with path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(headers)
            writer.writerows(rows)

    @staticmethod
    def _looks_like_file_result(url: str, title: str) -> bool:
        lower = f"{url} {title}".lower()
        return any(
            marker in lower
            for marker in (
                ".pdf",
                ".csv",
                ".xls",
                ".xlsx",
                ".doc",
                ".docx",
                ".zip",
                "[pdf]",
                "/download",
                "file-download",
            )
        )

    def __enter__(self) -> "ResearchStore":
        return self

    def __exit__(self, *_: object) -> None:
        return None
