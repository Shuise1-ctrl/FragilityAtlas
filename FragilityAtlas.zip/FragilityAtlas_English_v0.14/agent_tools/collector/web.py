from __future__ import annotations

import hashlib
import mimetypes
import os
import re
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from pathlib import Path

from .models import FileRecord, PageRecord


FILE_EXTENSIONS = {
    ".pdf",
    ".csv",
    ".xls",
    ".xlsx",
    ".doc",
    ".docx",
    ".ppt",
    ".pptx",
    ".txt",
    ".json",
    ".zip",
}


class BrowserVerificationError(RuntimeError):
    """A real browser was required but verification/download did not finish."""


class _PageParser(HTMLParser):
    def __init__(self, base_url: str) -> None:
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.title = ""
        self._in_title = False
        self._skip_depth = 0
        self._current_href: str | None = None
        self._current_text: list[str] = []
        self.text_parts: list[str] = []
        self.links: list[dict[str, str | bool]] = []

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        tag = tag.lower()
        if tag in {"script", "style", "noscript", "svg"}:
            self._skip_depth += 1
        if tag == "title":
            self._in_title = True
        if tag == "a":
            href = dict(attrs).get("href")
            self._current_href = (
                urllib.parse.urljoin(self.base_url, href) if href else None
            )
            self._current_text = []

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"script", "style", "noscript", "svg"} and self._skip_depth:
            self._skip_depth -= 1
        if tag == "title":
            self._in_title = False
        if tag == "a" and self._current_href:
            parsed = urllib.parse.urlparse(self._current_href)
            extension = Path(parsed.path).suffix.lower()
            self.links.append(
                {
                    "url": self._current_href,
                    "text": " ".join(self._current_text).strip(),
                    "is_file": extension in FILE_EXTENSIONS,
                }
            )
            self._current_href = None
            self._current_text = []

    def handle_data(self, data: str) -> None:
        text = " ".join(data.split())
        if not text or self._skip_depth:
            return
        if self._in_title:
            self.title = f"{self.title} {text}".strip()
        if self._current_href:
            self._current_text.append(text)
        self.text_parts.append(text)


def _safe_filename(name: str, fallback: str = "download") -> str:
    name = urllib.parse.unquote(name).strip()
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name)
    name = name.rstrip(" .")
    return name[:180] or fallback


class WebClient:
    def __init__(
        self,
        timeout: int,
        max_page_chars: int,
        max_file_bytes: int,
        user_agent: str = "DeepSeekResearchCollector/1.0",
        browser_enabled: bool = True,
        browser_headless: bool = False,
        browser_verify_timeout: int = 180,
        browser_download_timeout: int = 120,
        browser_profile_dir: Path = Path(".browser_profile"),
    ) -> None:
        self.timeout = timeout
        self.max_page_chars = max_page_chars
        self.max_file_bytes = max_file_bytes
        self.user_agent = user_agent
        self.browser_enabled = browser_enabled
        self.browser_headless = browser_headless
        self.browser_verify_timeout = browser_verify_timeout
        self.browser_download_timeout = browser_download_timeout
        self.browser_profile_dir = browser_profile_dir
        self._browser_driver = None
        self._browser_download_dir: Path | None = None

    def visit(
        self,
        url: str,
        *,
        depth: int = 0,
        parent_url: str | None = None,
    ) -> PageRecord:
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": self.user_agent,
                "Accept": "text/html,application/xhtml+xml,text/plain",
            },
        )
        try:
            with urllib.request.urlopen(
                request, timeout=self.timeout
            ) as response:
                content_type = response.headers.get_content_type()
                if content_type not in {"text/html", "application/xhtml+xml", "text/plain"}:
                    return PageRecord(
                        url=response.geturl(),
                        error=f"Unsupported page content type: {content_type}",
                        depth=depth,
                        parent_url=parent_url,
                    )
                raw = response.read(self.max_page_chars * 4)
                charset = response.headers.get_content_charset() or "utf-8"
                text = raw.decode(charset, errors="replace")
                final_url = response.geturl()
        except urllib.error.HTTPError as exc:
            if self.browser_enabled and exc.code in {403, 429, 503}:
                try:
                    return self._visit_with_browser(
                        url,
                        depth=depth,
                        parent_url=parent_url,
                    )
                except Exception as browser_error:
                    return PageRecord(
                        url=url,
                        error=f"{exc}; browser verification failed: {browser_error}",
                        depth=depth,
                        parent_url=parent_url,
                    )
            return PageRecord(
                url=url,
                error=str(exc),
                depth=depth,
                parent_url=parent_url,
            )
        except (urllib.error.URLError, TimeoutError) as exc:
            return PageRecord(
                url=url,
                error=str(exc),
                depth=depth,
                parent_url=parent_url,
            )

        if content_type == "text/plain":
            return PageRecord(
                url=final_url,
                text=text[: self.max_page_chars],
                depth=depth,
                parent_url=parent_url,
            )

        page = self._parse_html_page(
            final_url,
            text,
            depth=depth,
            parent_url=parent_url,
        )
        if self.browser_enabled and self._looks_like_verification_page(
            page.title,
            page.text,
            text,
        ):
            try:
                return self._visit_with_browser(
                    url,
                    depth=depth,
                    parent_url=parent_url,
                )
            except Exception as browser_error:
                page.error = f"Page verification was detected but browser verification failed: {browser_error}"
        return page

    def download(self, url: str, destination: Path) -> FileRecord:
        try:
            return self._download_http(url, destination)
        except BrowserVerificationError:
            if not self.browser_enabled:
                raise
            return self._download_with_browser(url, destination)
        except urllib.error.HTTPError as exc:
            if self.browser_enabled and exc.code in {403, 429, 503}:
                return self._download_with_browser(url, destination)
            raise

    def _download_http(
        self,
        url: str,
        destination: Path,
        headers: dict[str, str] | None = None,
    ) -> FileRecord:
        destination.mkdir(parents=True, exist_ok=True)
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": self.user_agent,
                "Accept": "*/*",
                **(headers or {}),
            },
        )
        try:
            with urllib.request.urlopen(
                request, timeout=self.timeout
            ) as response:
                content_length = response.headers.get("Content-Length")
                if content_length and int(content_length) > self.max_file_bytes:
                    raise ValueError(
                        f"File exceeds {self.max_file_bytes} byte limit"
                    )
                content_type = response.headers.get_content_type()
                if content_type in {"text/html", "application/xhtml+xml"}:
                    raise BrowserVerificationError(
                        f"Download URL returned a web page ({content_type})"
                    )
                filename = self._response_filename(response, url, content_type)
                target = self._unique_path(destination / filename)
                digest = hashlib.sha256()
                size = 0
                with target.open("wb") as handle:
                    first_chunk = response.read(64 * 1024)
                    if self._looks_like_html(first_chunk):
                        raise BrowserVerificationError(
                            "Download URL returned HTML content"
                        )
                    if first_chunk:
                        size = len(first_chunk)
                        if size > self.max_file_bytes:
                            raise ValueError(
                                f"File exceeds {self.max_file_bytes} byte limit"
                            )
                        digest.update(first_chunk)
                        handle.write(first_chunk)
                    while True:
                        chunk = response.read(64 * 1024)
                        if not chunk:
                            break
                        size += len(chunk)
                        if size > self.max_file_bytes:
                            raise ValueError(
                                f"File exceeds {self.max_file_bytes} byte limit"
                            )
                        digest.update(chunk)
                        handle.write(chunk)
        except Exception:
            if "target" in locals() and target.exists():
                target.unlink()
            raise

        return FileRecord(
            source_url=url,
            local_path=str(target.resolve()),
            content_type=content_type,
            sha256=digest.hexdigest(),
            size=size,
        )

    def _visit_with_browser(
        self,
        url: str,
        *,
        depth: int,
        parent_url: str | None,
    ) -> PageRecord:
        if self.browser_headless:
            raise BrowserVerificationError(
                "Headless browsing is enabled, so human verification cannot be completed; "
                "set COLLECTOR_BROWSER_HEADLESS=false"
            )
        driver = self._get_browser_driver(
            self.browser_profile_dir / "browser_downloads"
        )
        self._browser_get(driver, url)
        self._wait_for_manual_verification(url)
        return self._parse_html_page(
            driver.current_url,
            driver.page_source,
            depth=depth,
            parent_url=parent_url,
        )

    def _download_with_browser(
        self,
        url: str,
        destination: Path,
    ) -> FileRecord:
        if self.browser_headless:
            raise BrowserVerificationError(
                "A verification page was detected, but headless browsing is enabled; "
                "set COLLECTOR_BROWSER_HEADLESS=false and retry."
            )
        destination.mkdir(parents=True, exist_ok=True)
        staging = destination / ".browser_staging"
        staging.mkdir(parents=True, exist_ok=True)
        before = {path.resolve() for path in staging.iterdir()}
        driver = self._get_browser_driver(staging)
        self._browser_get(driver, url)

        downloaded = self._wait_for_browser_download(
            staging,
            before,
            timeout=min(self.browser_verify_timeout, 10),
        )
        if downloaded is None:
            self._wait_for_manual_verification(url)
            downloaded = self._wait_for_browser_download(
                staging,
                before,
                timeout=self.browser_download_timeout,
            )
        if downloaded is not None:
            return self._move_browser_download(downloaded, url, destination)

        # After the user completes the challenge, the original URL may work
        # with the browser's cookies even though urllib did not have them.
        headers = self._browser_headers(driver)
        try:
            return self._download_http(url, destination, headers=headers)
        except (BrowserVerificationError, urllib.error.HTTPError):
            pass

        # Some sites expose the real attachment only after verification.
        for candidate_url in self._browser_file_links(driver):
            try:
                return self._download_http(
                    candidate_url,
                    destination,
                    headers=headers,
                )
            except (BrowserVerificationError, urllib.error.HTTPError, ValueError):
                continue
        raise BrowserVerificationError(
            "No file download was detected after verification. Complete the browser challenge and click the download button, then retry."
        )

    def _get_browser_driver(self, download_dir: Path):
        if self._browser_driver is not None:
            self._set_browser_download_dir(download_dir)
            return self._browser_driver
        try:
            from selenium import webdriver
            from selenium.webdriver.edge.options import Options
        except ImportError as exc:
            raise BrowserVerificationError(
                "A browser verification page was detected, but Selenium is not installed. Run "
                "python -m pip install -r requirements.txt"
            ) from exc

        profile_dir = self.browser_profile_dir.resolve()
        profile_dir.mkdir(parents=True, exist_ok=True)
        download_dir.mkdir(parents=True, exist_ok=True)
        options = Options()
        if self.browser_headless:
            options.add_argument("--headless=new")
        options.add_argument("--disable-popup-blocking")
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        options.add_argument(f"--user-data-dir={profile_dir}")
        options.add_experimental_option(
            "prefs",
            {
                "download.default_directory": str(download_dir.resolve()),
                "download.prompt_for_download": False,
                "download.directory_upgrade": True,
                "safebrowsing.enabled": True,
            },
        )
        try:
            self._browser_driver = webdriver.Edge(options=options)
            self._browser_driver.set_page_load_timeout(
                max(self.timeout, self.browser_verify_timeout)
            )
            self._set_browser_download_dir(download_dir)
            return self._browser_driver
        except Exception as exc:
            raise BrowserVerificationError(
                f"Could not start Microsoft Edge: {exc}"
            ) from exc

    def _set_browser_download_dir(self, download_dir: Path) -> None:
        download_dir.mkdir(parents=True, exist_ok=True)
        self._browser_download_dir = download_dir.resolve()
        if self._browser_driver is None:
            return
        try:
            self._browser_driver.execute_cdp_cmd(
                "Browser.setDownloadBehavior",
                {
                    "behavior": "allow",
                    "downloadPath": str(self._browser_download_dir),
                },
            )
        except Exception:
            # Edge's download preferences remain as a fallback.
            pass

    @staticmethod
    def _browser_get(driver, url: str) -> None:
        try:
            driver.get(url)
        except Exception as exc:
            name = type(exc).__name__
            if name != "TimeoutException":
                raise

    def _wait_for_manual_verification(self, url: str) -> None:
        print("\n[Browser verification] Opened a page requiring verification:")
        print(url)
        print(
            "Complete the verification challenge in Microsoft Edge. "
            "If a download button appears, click it as well."
        )
        deadline = time.monotonic() + self.browser_verify_timeout
        if os.name == "nt":
            import msvcrt

            print(
                f"Complete verification within {self.browser_verify_timeout} seconds, "
                "then return here and press Enter: ",
                end="",
                flush=True,
            )
            while time.monotonic() < deadline:
                if msvcrt.kbhit():
                    key = msvcrt.getwch()
                    if key in {"\r", "\n"}:
                        print()
                        return
                time.sleep(0.2)
            print()
            raise BrowserVerificationError(
                f"Human verification exceeded {self.browser_verify_timeout} seconds"
            )
        try:
            input("When finished, return here and press Enter: ")
        except EOFError as exc:
            raise BrowserVerificationError(
                "This runtime cannot accept human verification input"
            ) from exc

    def _wait_for_browser_download(
        self,
        staging: Path,
        before: set[Path],
        *,
        timeout: int,
    ) -> Path | None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            for path in staging.iterdir():
                if (
                    not path.is_file()
                    or path.resolve() in before
                    or path.suffix.lower() in {".crdownload", ".tmp", ".part"}
                ):
                    continue
                try:
                    size = path.stat().st_size
                    time.sleep(0.3)
                    if size == path.stat().st_size and size > 0:
                        return path
                except FileNotFoundError:
                    continue
            time.sleep(0.5)
        return None

    def _move_browser_download(
        self,
        source: Path,
        source_url: str,
        destination: Path,
    ) -> FileRecord:
        size = source.stat().st_size
        if size > self.max_file_bytes:
            source.unlink(missing_ok=True)
            raise ValueError(f"File exceeds {self.max_file_bytes} byte limit")
        target = self._unique_path(destination / _safe_filename(source.name))
        shutil.move(str(source), str(target))
        return self._file_record_from_path(source_url, target)

    @staticmethod
    def _file_record_from_path(source_url: str, path: Path) -> FileRecord:
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(64 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
                size += len(chunk)
        return FileRecord(
            source_url=source_url,
            local_path=str(path.resolve()),
            content_type=mimetypes.guess_type(path.name)[0]
            or "application/octet-stream",
            sha256=digest.hexdigest(),
            size=size,
        )

    def _browser_headers(self, driver) -> dict[str, str]:
        cookies = driver.get_cookies()
        cookie_header = "; ".join(
            f"{item['name']}={item['value']}" for item in cookies
        )
        try:
            user_agent = str(
                driver.execute_script("return navigator.userAgent")
            )
        except Exception:
            user_agent = self.user_agent
        headers = {"User-Agent": user_agent}
        if cookie_header:
            headers["Cookie"] = cookie_header
        return headers

    @staticmethod
    def _browser_file_links(driver) -> list[str]:
        try:
            elements = driver.find_elements("css selector", "a[href]")
        except Exception:
            return []
        candidates: list[str] = []
        for element in elements:
            href = str(element.get_attribute("href") or "").strip()
            text = str(element.text or "").strip().lower()
            download_attr = str(element.get_attribute("download") or "").lower()
            lower = href.lower()
            suffix = Path(urllib.parse.urlparse(href).path).suffix.lower()
            if (
                href.startswith(("http://", "https://"))
                and (
                    suffix in FILE_EXTENSIONS
                    or "download" in lower
                    or "下载" in text
                    or download_attr
                )
                and href not in candidates
            ):
                candidates.append(href)
        return candidates

    @staticmethod
    def _parse_html_page(
        url: str,
        text: str,
        *,
        depth: int,
        parent_url: str | None,
    ) -> PageRecord:
        parser = _PageParser(url)
        try:
            parser.feed(text)
        except Exception as exc:
            return PageRecord(
                url=url,
                error=f"HTML parse failed: {exc}",
                depth=depth,
                parent_url=parent_url,
            )
        page_text = "\n".join(parser.text_parts)
        unique_links = {
            str(item["url"]): item
            for item in parser.links
            if str(item["url"]).startswith(("http://", "https://"))
        }
        return PageRecord(
            url=url,
            title=parser.title,
            text=page_text[:30_000],
            links=list(unique_links.values()),
            depth=depth,
            parent_url=parent_url,
        )

    @staticmethod
    def _looks_like_verification_page(
        title: str,
        visible_text: str,
        raw_html: str,
    ) -> bool:
        haystack = " ".join(
            [title, visible_text[:8_000], raw_html[:12_000]]
        ).casefold()
        markers = (
            "verify you are human",
            "checking your browser",
            "just a moment",
            "cf-chl-",
            "challenge-platform",
            "captcha",
            "hcaptcha",
            "turnstile",
            "人机验证",
            "安全验证",
            "请完成验证",
            "验证您是真人",
            "滑动验证",
            "访问验证",
        )
        return any(marker.casefold() in haystack for marker in markers)

    def close(self) -> None:
        if self._browser_driver is None:
            return
        try:
            self._browser_driver.quit()
        finally:
            self._browser_driver = None

    @staticmethod
    def _looks_like_html(content: bytes) -> bool:
        prefix = content[:1024].lstrip().lower()
        return prefix.startswith((b"<!doctype html", b"<html", b"<head", b"<body"))

    @staticmethod
    def _response_filename(
        response: object, url: str, content_type: str
    ) -> str:
        headers = getattr(response, "headers")
        disposition = headers.get("Content-Disposition", "")
        match = re.search(
            r"filename\*=UTF-8''([^;]+)|filename=\"?([^\";]+)",
            disposition,
            flags=re.IGNORECASE,
        )
        candidate = next(
            (group for group in match.groups() if group), ""
        ) if match else ""
        if not candidate:
            candidate = Path(urllib.parse.urlparse(url).path).name
        if not Path(candidate).suffix:
            candidate += mimetypes.guess_extension(content_type) or ".bin"
        return _safe_filename(candidate)

    @staticmethod
    def _unique_path(path: Path) -> Path:
        if not path.exists():
            return path
        for index in range(1, 10_000):
            candidate = path.with_name(f"{path.stem}_{index}{path.suffix}")
            if not candidate.exists():
                return candidate
        raise RuntimeError(f"Unable to allocate a unique filename for {path}")
