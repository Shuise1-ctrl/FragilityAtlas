from __future__ import annotations

import json
import http.client
import socket
import time
import urllib.error
import urllib.request
from typing import Any


class HttpError(RuntimeError):
    pass


class JsonHttpClient:
    def __init__(
        self,
        timeout: int = 30,
        user_agent: str = "DeepSeekResearchCollector/1.0",
        retries: int = 2,
    ) -> None:
        self.timeout = timeout
        self.user_agent = user_agent
        self.retries = retries

    def request_json(
        self,
        url: str,
        *,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        request_headers = {
            "Accept": "application/json",
            "User-Agent": self.user_agent,
            **(headers or {}),
        }
        if body is not None:
            request_headers.setdefault("Content-Type", "application/json")

        last_error: Exception | None = None
        for attempt in range(self.retries + 1):
            request = urllib.request.Request(
                url,
                data=body,
                headers=request_headers,
                method=method,
            )
            try:
                with urllib.request.urlopen(
                    request, timeout=self.timeout
                ) as response:
                    charset = response.headers.get_content_charset() or "utf-8"
                    decoded = response.read().decode(charset, errors="replace")
                    value = json.loads(decoded)
                    if not isinstance(value, dict):
                        raise HttpError(f"Expected JSON object from {url}")
                    return value
            except urllib.error.HTTPError as exc:
                error_body = exc.read().decode("utf-8", errors="replace").strip()
                detail = f"HTTP {exc.code} {exc.reason}"
                if error_body:
                    detail += f": {error_body[:2000]}"
                last_error = HttpError(detail)
                if 400 <= exc.code < 500 and exc.code != 429:
                    break
                if attempt < self.retries:
                    time.sleep(0.5 * (2**attempt))
            except (
                urllib.error.URLError,
                TimeoutError,
                ConnectionError,
                ConnectionResetError,
                http.client.RemoteDisconnected,
                http.client.IncompleteRead,
                socket.timeout,
                json.JSONDecodeError,
            ) as exc:
                last_error = exc
                if attempt < self.retries:
                    time.sleep(0.5 * (2**attempt))

        raise HttpError(f"Request failed for {url}: {last_error}") from last_error
