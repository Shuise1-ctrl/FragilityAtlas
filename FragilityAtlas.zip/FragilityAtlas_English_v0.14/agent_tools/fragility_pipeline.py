#!/usr/bin/env python3
"""Repeatable, single-writer PDF -> Word -> fragility candidates -> Excel workflow."""
from __future__ import annotations
import argparse, hashlib, json, math, os, re, shutil, time
from pathlib import Path

FIELDS=["Country","Building_Type","Seismic_Level","Damage_State","Condition","Function_Type","Function_Expression","Inputs","a","b","c","d","e","Parameter_Names","Output","Source","Notes"]
REQ={"pypdf":"native PDF text","docx":"Word review packets","openpyxl":"Excel workbook","pypdfium2":"page-image evidence (recommended)"}; NUM=r"[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?"

def deps():
    ok=True
    for m,purpose in REQ.items():
        try: __import__(m); print(f"OK   {m}: {purpose}")
        except Exception as e:
            print(f"MISS {m}: {purpose} ({e})")
            if m in ("pypdf","docx","openpyxl"): ok=False
    print("PADDLEOCR_ACCESS_TOKEN: present" if os.environ.get("PADDLEOCR_ACCESS_TOKEN") else "PADDLEOCR_ACCESS_TOKEN: absent (not required; API is not used)"); return ok

def digest(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def pages(pdf):
    from pypdf import PdfReader
    r=PdfReader(str(pdf)); return [(i,p.extract_text() or "") for i,p in enumerate(r.pages,1)]

def render(pdf,focus,out):
    try: import pypdfium2 as pdfium
    except Exception: return []
    out.mkdir(parents=True,exist_ok=True); doc=pdfium.PdfDocument(str(pdf)); result=[]
    for p in sorted(set(focus)):
        if 1<=p<=len(doc):
            dest=out/f"{Path(pdf).stem}_p{p}.png"; doc[p-1].render(scale=1.8).to_pil().save(dest); result.append(str(dest))
    return result

def nhess(pdf,ps):
    rows=[]; src="nhess-2018-254.pdf Table 4, PDF pp. 30–31"; source=build=level=""
    for page,text in ps:
        if page not in (30,31): continue
        for raw in text.splitlines():
            s=" ".join(raw.split())
            if s.lower().startswith("empirical"): source="empirical"
            if s.lower().startswith("analytical"): source="analytical"
            m=re.search(r"\b(masonry|RC)\s*[_ ]?([AB])\b",s,re.I)
            if m: build=m.group(1)+"_"+m.group(2).upper(); level=m.group(2).upper()
            m=re.search(r"\b(LS[1-4])\s+(%s)\s+(%s)\s+(%s)"%(NUM,NUM,NUM),s)
            if not(m and source and build): continue
            ls,mu,sig,r2=m.groups(); cond="empirical" if source=="empirical" else "analytical"; inp="X1=X_int (intensity)" if cond=="empirical" else "X1=X_PGA (PGA, g)"; expr="Phi((X1-mu_LS)/sigma_LS)" if cond=="empirical" else "Phi((ln(X1/mu_LS))/sigma_LS)"
            rows.append({"Country":"China","Building_Type":build,"Seismic_Level":level,"Damage_State":ls,"Condition":cond,"Function_Type":"exceedance probability; normal/lognormal fit","Function_Expression":expr,"Inputs":inp,"a":mu,"b":sig,"c":"","d":"","e":"","Parameter_Names":f"mu_LS={mu} (source; {'intensity level' if cond=='empirical' else 'g'}); sigma_LS={sig} (source; dimensionless log-space dispersion)","Output":"P(X1 >= LS)","Source":src,"Notes":f"candidate; R-square={r2}; LS mapping preserved: LS1 slight, LS2 moderate, LS3 serious, LS4 collapse. A=pre/low/moderate-code; B=high-code. No assumptions."})
    return rows

def cjge(pdf,ps):
    out=[]; formulas={10:("1.114","1.116","single horizontal earthquake","PDF p. 8, Eq. (10)"),12:("1.127","1.287","bi-directional earthquake","PDF p. 8, Eq. (12)")}; states=[("S1","正常使用",0.11,0.13),("S2","立即使用",0.17,0.17),("S3","生命安全",0.40,0.38),("S4","防止倒塌",0.70,0.65)]
    for eq,(A,power,cond,src) in formulas.items():
        for state,cn,single50,bi50 in states:
            p50=single50 if eq==10 else bi50; uc=round(float(A)*p50**float(power),8); expr=f"Phi(ln(({A}*X1^{power})/u_c)/beta_tot)"
            note=f"candidate; Eq. ({eq}) applies to IDR; state preserved: {state} {cn}. u_c={uc} is DERIVED from Table 6 50% PGA={p50} g and Eq. ({eq}) at Pf=0.5; beta_tot missing from cited content and remains blank. Do not draw approved curve until verified. site II is Condition, not Seismic_Level. No assumed beta or zero value."
            out.append({"Country":"China","Building_Type":"ULSFS large-space underground frame","Seismic_Level":"","Damage_State":state,"Condition":cond,"Function_Type":"lognormal failure/exceedance probability","Function_Expression":expr,"Inputs":"X1=PGA (g); u_c derived from Table 6; beta_tot required","a":A,"b":power,"c":uc,"d":"","e":"","Parameter_Names":f"A={A} (source coefficient); power={power} (source exponent); u_c={uc} (derived); beta_tot (missing)","Output":"P_f^IDR (failure probability; exceedance)","Source":f"CJGE20221053.pdf {src}; associated Table 6, PDF p. 9","Notes":note})
    return out

def fit_lognormal(points):
    """Bounded grid fit for P=Phi(ln(X/mu)/sigma); never evaluates source text."""
    phi=lambda z:0.5*(1+math.erf(z/math.sqrt(2)))
    pts=[(float(p["x"]),float(p["y"])) for p in points if 0<float(p.get("x",0)) and 0<=float(p.get("y",-1))<=1]
    if len(pts)>60:
        keep=[round(i*(len(pts)-1)/59) for i in range(60)]
        pts=[pts[i] for i in keep]
    if len(pts)<4: return "","", "fewer than 4 calibrated points"
    lo=min(x for x,y in pts); hi=max(x for x,y in pts); best=(float("inf"),"","")
    for pass_no,(n,sl,ss) in enumerate(((48,0.02,0.02),(40,0.0025,0.0025),(40,0.0005,0.0005))):
        mu0=lo+(hi-lo)*0.5 if not best[1] else float(best[1]); sig0=0.6 if not best[2] else float(best[2]); mr=max(hi-lo,0.001)
        for i in range(n):
            mu=max(1e-12,mu0+((i-(n-1)/2)/(n-1))*mr*sl*20); 
            for j in range(n):
                sig=max(0.02,sig0+((j-(n-1)/2)/(n-1))*2*ss*20); err=sum((phi(math.log(x/mu)/sig)-y)**2 for x,y in pts)
                if err<best[0]: best=(err,str(mu),str(sig))
        mu0=float(best[1]); sig0=float(best[2]); mr=max(mr*sl*20,0.001)
    return round(float(best[1]),8),round(float(best[2]),8),f"grid-fit SSE={best[0]:.6g}"

def _vector_curve(form_data, color_pattern):
    """Read one colored vector trace from a figure Form XObject.

    The parser accepts only PDF path coordinates and never evaluates document text.
    It deliberately selects the longest path after the requested RGB stroke color;
    short legend samples are therefore not mistaken for data curves.
    """
    rects=[]
    for m in re.finditer(rf"({NUM})\s+({NUM})\s+({NUM})\s+({NUM})\s+re\b",form_data):
        x0,y0,w,h=map(float,m.groups())
        if w>50 and h>50: rects.append((x0,y0,w,h))
    if not rects: raise ValueError("plot rectangle not found in vector figure")
    x0,y0,w,h=rects[0]
    hits=list(re.finditer(color_pattern,form_data))
    if not hits: raise ValueError(f"curve color not found: {color_pattern}")
    start=hits[0].end(); next_hits=[m.start() for m in re.finditer(r"(?:0\s+0\.451\s+0\.741|0\.471\s+0\.671\s+0\.188|0\.929\s+0\.69\s+0\.129|0\.89\s+0\.122\s+0\.122)\s+RG",form_data[start:])]
    end=start+(min(next_hits) if next_hits else len(form_data[start:]))
    block=form_data[start:end]
    line_pattern=re.compile(rf"^\s*({NUM})\s+({NUM})\s+([ml])\s*$")
    paths=[]; current=[]
    for line in block.splitlines():
        m=line_pattern.match(line)
        if m:
            current.append((float(m.group(1)),float(m.group(2))))
        elif line.strip() in ("S","s"):
            if current: paths.append(current); current=[]
    if current: paths.append(current)
    if not paths: raise ValueError("no vector path after curve color")
    path=max(paths,key=len)
    if len(path)<20: raise ValueError("selected vector path is too short")
    points=[]
    for x,y in path:
        xd=max(0.0,min(3.0,(x-x0)/w*3.0)); yd=max(0.0,min(1.0,(y-y0)/h))
        points.append({"x":round(xd,8),"y":round(yd,8)})
    return points

def nhess2022_figure10(item,pdf,ps):
    """Extract the 14 x 4 cumulative traces in Figure 10 of nhess-2022-73.

    Figure 10 is stored as fourteen vector Form XObjects.  This scoped extractor
    uses the original vector paths, maps each trace to the fixed taxonomy and
    damage-state labels, then fits only the stated lognormal family.  It does not
    invent a seismic level or printed parameters that are absent from the paper.
    """
    from pypdf import PdfReader
    reader=PdfReader(str(pdf)); forms=[]
    color_patterns=[r"0\s+0\.451\s+0\.741\s+RG",r"0\.471\s+0\.671\s+0\.188\s+RG",r"0\.929\s+0\.69\s+0\.129\s+RG",r"0\.89\s+0\.122\s+0\.122\s+RG"]
    for page_no in (17,18):
        xobj=reader.pages[page_no-1]["/Resources"]["/XObject"].get_object()
        for _,ref in xobj.items():
            form=ref.get_object()
            if form.get("/Subtype")!="/Form": continue
            data=form.get_data().decode("latin1")
            try: curves=[_vector_curve(data,c) for c in color_patterns]
            except ValueError: continue
            if all(len(c)>=20 for c in curves): forms.append((page_no,curves))
    if len(forms)!=14: raise RuntimeError(f"Expected 14 Figure 10 vector panels, found {len(forms)}")
    building_types=[
        "CR/LFINF/DUC/H:1","CR/LFINF/DUC/H:2","CR/LFINF/DUC/H:3",
        "MCF/LWAL/DNO/H:1","MCF/LWAL/DNO/H:2","MCF/LWAL/DNO/H:3",
        "MR/LWAL/DUC/H:1","MR/LWAL/DUC/H:2","MR/LWAL/DUC/H:3",
        "MUR/LWAL/DNO/H:1","MUR/LWAL/DNO/H:2","MUR/LWAL/DNO/H:3",
        "W/WLI/DUC/H:1","W/WLI/DUC/H:2"]
    x_labels=["PGA(g)","SA(0.3)","SA(0.3)","PGA(g)","SA(0.3)","SA(1.0)","PGA(g)","SA(0.3)","SA(0.3)","SA(0.3)","SA(0.3)","SA(0.3)","SA(0.3)","SA(0.3)"]
    letters=list("abcdefghijklmn"); states=["Slight","Moderate","Extensive","Collapse"]
    specs=[]
    for idx,((page_no,curves),building,xlabel,letter) in enumerate(zip(forms,building_types,x_labels,letters)):
        for state,points in zip(states,curves):
            specs.append({
                "page":page_no,"figure":f"Figure 10 subplot ({letter})","building_type":building,
                "seismic_level":"","damage_state":state,
                "condition":"Sabana Centro; ground shaking intensity; Figure 10 literature curve",
                "function_type":"lognormal exceedance probability (digitized vector curve)",
                "function_expression":"P(DS >= state | X1) = Phi(ln(X1/a)/b)",
                "inputs":f"X1={xlabel}; Y=probability of exceedance; x range 0–3 as plotted",
                "y_label":"Probability of exceedance","fit":True,"points":points,
                "parameter_names":"a=median X1 from fitted vector trace; b=sigma, log-space dispersion from fitted vector trace; c,d,e=not used; original printed numeric parameters not found",
                "output":"Probability of exceedance",
                "source_context":"Table 4 taxonomy PDF p. 13; methods PDF p. 16; Figure 10 caption PDF p. 18",
                "notes":"Paper states cumulative probability curves with a lognormal distribution and four states (Slight, Moderate, Extensive, Collapse). Taxonomy and state labels are retained verbatim; Seismic_Level is not stated and is left blank. Fit is a derived candidate from the original vector trace, not a printed parameter."})
    return curve_image_candidates({**item,"curves":specs},pdf,ps)

def curve_image_candidates(item,pdf,ps):
    """Create auditable records for figure-only papers.

    Manifest curve specs are intentionally explicit: a human/agent must supply page,
    labels and calibrated x/y points after viewing the original figure. This prevents
    silent pixel-coordinate or legend guesses.
    """
    specs=item.get("curves",[]); found=[]
    if not specs:
        for p,t in ps:
            if re.search(r"fragility|vulnerability|易损|脆弱|曲线|curve",t,re.I):
                found.append({"page":p,"notes":"figure page detected; add calibrated curve spec before parameter fitting"})
        specs=found[:20]
    out=[]
    for spec in specs:
        pts=spec.get("points",[]); family=spec.get("function_type",""); family_lower=family.lower(); is_lognormal=(family_lower in ("lognormal","lognormal_exceedance") or "lognormal" in family_lower); a=b=c=d=e=""; fitnote=""
        if spec.get("fit") and is_lognormal:
            a,b,fitnote=fit_lognormal(pts)
        expr=spec.get("function_expression") or ("Phi(ln(X1/a)/b)" if is_lognormal else "Y=f(X1) [digitized curve points]")
        input_text=spec.get("inputs") or f"X1={spec.get('x_label','')} ({spec.get('x_unit','')}); Y={spec.get('y_label','')}"
        note=f"candidate; {spec.get('notes','')} curve-image evidence, PDF page {spec.get('page','')}. {fitnote or 'No parameter fit performed.'} Calibrated points are derived from the original figure; verify axes, legend and stated function before approval."
        if not pts: note += " No points supplied; parameters remain blank."
        source=f"{pdf.name}, PDF p. {spec.get('page','')}, {spec.get('figure','curve image')}"+(f"; {spec['source_context']}" if spec.get("source_context") else "")
        out.append({"Country":item.get("country",""),"Building_Type":spec.get("building_type",""),"Seismic_Level":spec.get("seismic_level",""),"Damage_State":spec.get("damage_state",""),"Condition":spec.get("condition",""),"Function_Type":family or "curve_image_candidate","Function_Expression":expr,"Inputs":input_text,"a":a,"b":b,"c":c,"d":d,"e":e,"Parameter_Names":spec.get("parameter_names","")+(("; a=mu (fitted median); b=sigma (fitted dispersion)" if a and b else "")),"Output":spec.get("output",spec.get("y_label","")),"Source":source,"Notes":note})
    return out,sorted({int(s.get("page")) for s in specs if str(s.get("page","")).isdigit()})

def _rec(country,building,level,state,condition,ftype,expr,inputs,a="",b="",c="",d="",e="",pnames="",output="",source="",notes=""):
    return {"Country":country,"Building_Type":building,"Seismic_Level":level,"Damage_State":state,"Condition":condition,"Function_Type":ftype,"Function_Expression":expr,"Inputs":inputs,"a":a,"b":b,"c":c,"d":d,"e":e,"Parameter_Names":pnames,"Output":output,"Source":source,"Notes":notes}

def buildings2023(pdf,ps):
    """Parse the printed fragility parameter tables 7 and 8 from Buildings 2023."""
    text={p:t for p,t in ps}; parts=[]
    for page_no,start,end in ((10,"Table 7.","For an elastic system"),(11,"Table 8. Cont.","For an elastic system")):
        t=text.get(page_no,"");
        if start in t:
            s=t[t.index(start):]; parts.append(s[:s.index(end)] if end in s else s)
    joined="\n".join(parts); row_re=re.compile(r"(?m)(?:^|\n)\s*([BPT]\d+(?:&T\d+)?-(?:ST|RC)-[LM]-V[34])(?=\s)"); matches=list(row_re.finditer(joined))
    rows=[]
    for i,m in enumerate(matches):
        chunk=joined[m.end():(matches[i+1].start() if i+1<len(matches) else len(joined))]
        nums=[float(x) for x in re.findall(NUM,chunk)]
        if len(nums)>=9: nums=nums[-8:]
        if len(nums)!=8: continue
        typ=m.group(1); code="moderate-code" if typ.endswith("V3") else "high-code"; source=f"{pdf.name}, PDF p. 10–11, Table 7/8, {typ}"
        for state in range(4):
            a,b=nums[state*2:state*2+2]
            rows.append(_rec("Iran",typ,typ[-2:],f"D{state+1}","rocky ground type I; high-risk zone; LM2 RISK-UE hybrid method","lognormal exceedance probability",f"P(DS >= D{state+1} | X1) = Phi(ln(X1/a)/b)","X1=Sd spectral displacement (cm)",a,b,"","","",f"a=Sd_D{state+1} median (cm); b=beta_D{state+1} lognormal standard deviation (dimensionless); D1=minor, D2=moderate, D3=severe, D4=collapse", "Probability of exceedance",source,f"source table parameter; {code}; Table 3 damage labels preserved; Eq. (4) and Eqs. (5)–(12) define the median/beta construction; no assumptions."))
    if not rows: raise RuntimeError("No Buildings 2023 Table 7/8 rows parsed")
    return rows,[10,11,5,9]

def hospital_hazus(pdf,ps):
    """Parse the ten-hospital HAZUS fragility parameter rows in Table 3."""
    text={p:t for p,t in ps}; t=text.get(6,""); start=t.index("Table 3 Structural Fragility Curve Parameter") if "Table 3 Structural Fragility Curve Parameter" in t else 0; end=t.index("Damage probability value",start) if "Damage probability value" in t[start:] else len(t); seg=t[start:end]
    row_re=re.compile(rf"(?m)^\s*\d+\s+(.+?)\s+(C1[LMH])\s+(Low|Moderate|High)\s+((?:{NUM}\s+){{7}}{NUM})\s*$"); rows=[]
    for m in row_re.finditer(seg):
        name,typ,level=m.group(1).strip(),m.group(2),m.group(3); nums=[float(x) for x in re.findall(NUM,m.group(4))]
        for state,label in enumerate(("Slight","Moderate","Extensive","Complete")):
            a,b=nums[state*2:state*2+2]
            rows.append(_rec("Indonesia",f"{name} [{typ}]",level,label,"North Jakarta/West Jakarta; hospital building; HAZUS; soft-soil study context","HAZUS lognormal exceedance probability","P(DS >= state | X1) = Phi(ln(X1/a)/b)","X1=Sd inelastic spectral displacement (inches)",a,b,"","","",f"a=Sd_hat_{label} median (in); b=beta_{label} lognormal deviation (dimensionless); source label Complete preserved", "Probability of exceedance",f"{pdf.name}, PDF p. 6, Table 3", "source table parameter; paper's Eq. (4) uses cumulative damage probability; do not confuse cumulative exceedance with discrete damage probability in Table 5; no assumptions."))
    if len(rows)!=40: raise RuntimeError(f"Expected 40 hospital rows, parsed {len(rows)}")
    return rows,[4,5,6,7,8,9]

def awchat2023(pdf,ps):
    text={p:t for p,t in ps}; t=text.get(6,""); m=re.search(r"μ\s+(-?\d+(?:\.\d+)?).*?μ\s+(-?\d+(?:\.\d+)?).*?μ\s+(-?\d+(?:\.\d+)?).*?σ\s+(\d+(?:\.\d+)?).*?σ\s+(\d+(?:\.\d+)?).*?σ\s+(\d+(?:\.\d+)?)",t,re.S)
    if not m: raise RuntimeError("Awchat means/SDs not found on PDF p. 6")
    mus=list(map(float,m.groups()[:3])); sigs=list(map(float,m.groups()[3:])); rows=[]
    for state,mu,sig in zip(("IO","LS","CP"),mus,sigs):
        rows.append(_rec("India","G+7 reinforced-concrete moment-resisting frame","",state,"Nanded, Maharashtra; IS-code frame; multi-record IDA; far-field and near-fault ground motions","lognormal exceedance probability (source ln-space parameters)","P(DS >= state | X1) = Phi((ln(X1)-a)/b)","X1=Sa(T1,5%) spectral acceleration (g)",mu,sig,"","","","a=mu, mean of ln(X1); b=sigma, standard deviation of ln(X1); source values are not converted to a median", "Probability of exceedance",f"{pdf.name}, PDF p. 6, Table 3", "source mean and standard deviation; IO/LS/CP preserved; paper reports maximum exceedance probabilities 87.31%, 92.31% and 90.69%; no assumptions."))
    return rows,[1,4,6]

def jurnal2024(pdf,ps):
    text={p:t for p,t in ps}; t=text.get(7,""); alltext=t+"\n"+text.get(8,""); table=t[t.index("Tabel 6. Hasil nilai probabilitas kerentanan"):] if "Tabel 6. Hasil nilai probabilitas kerentanan" in t else t
    points={s:[] for s in ("OP","IO","DC","LS","CP")}; ims=[]
    for line in table.splitlines():
        m=re.match(r"^\s*(0,[1-9]|1)\s+((?:\d+\.\d{3}\s+){4}\d+\.\d{3})\s*$",line)
        if m:
            ims.append(float(m.group(1).replace(",","."))); vals=list(map(float,m.group(2).split()));
            for state,val in zip(points,vals): points[state].append(val)
    if len(ims)!=10: raise RuntimeError(f"Expected 10 Table 6 IM rows, parsed {len(ims)}")
    m50=re.search(r"0,18g.*?0,28g.*?0,37g.*?0,46g.*?0,54g",alltext,re.S)
    if not m50: raise RuntimeError("Jurnal 2024 reported 50% crossing values not found")
    medians=[0.18,0.28,0.37,0.46,0.54]; rows=[]
    for state,median in zip(points,medians):
        compact="; ".join(f"{x:g}:{y:.3f}" for x,y in zip(ims,points[state]))
        rows.append(_rec("Indonesia","Permanent-housing single-storey model (hunian tetap)","",state,"Desa Nagrak, Kabupaten Cianjur; non-engineered dwelling analyzed with engineered-building standards; nonlinear time-history","probability-of-damage curve; lognormal candidate","P(performance state reached/exceeded | X1) = Phi(ln(X1/a)/b)","X1=IM/PGA (g); Table 6 discrete probabilities",median,"","","","",f"a=reported IM at 50% probability crossing (derived median, g); b=logarithmic SD not reported; original state={state}","Paper probability of damage at performance level",f"{pdf.name}, PDF p. 7, Table 6 and text after Fig. 15",f"candidate; Table 6 points IM:P={compact}; b missing; the formula image on PDF p. 6–7 needs visual confirmation; reported 50% crossing is used only as a derived a; no assumed b."))
    return rows,[5,6,7,8]

def australia_nz_2020(pdf,ps):
    """Parse the printed URM component fragility table for Australia/New Zealand."""
    table={
        "One-storey":{"AB":(0.37,0.95),"R":(0.60,0.81),"P":(0.13,0.55),"C":(0.28,0.54)},
        "Two-storey":{"AB":(0.15,0.98),"R":(0.26,0.89),"P":(0.05,0.64),"C":(0.12,0.63)},
        "Three-storey":{"AB":(0.14,1.08),"R":(0.26,0.91),"P":(0.04,0.65),"C":(0.10,0.70)},
    }
    meanings={
        "AB":"as-built two-way spanning wall/façade",
        "R":"retrofitted wall-diaphragm connection/façade",
        "P":"parapet",
        "C":"chimney",
    }
    rows=[]
    for height,prototypes in table.items():
        for proto,(median,beta) in prototypes.items():
            rows.append(_rec(
                "Australia and New Zealand",
                f"low-rise pre-1940 stand-alone URM building, {height}; Prototype {proto}",
                "",
                "DS (peak strength/damage threshold)",
                f"URM component: {meanings[proto]}; one damage state represented by component peak strength",
                "lognormal exceedance probability",
                "P(DS >= threshold | X1) = Phi(ln(X1/a)/b)",
                "X1=PGA (g)",median,beta,"","","",
                f"a=Median PGA (g), source Table 3; b=Standard Deviation, source Table 3 and lognormal fit (dimensionless log-space dispersion); prototype={proto} ({meanings[proto]})",
                "Probability of exceeding component damage threshold",
                f"{pdf.name}, PDF p. 11, Table 3; Fragility Curves section PDF pp. 10–11",
                "source printed parameters; paper studies low-rise pre-1940 buildings in Australia and New Zealand; one damage state is the component peak strength and is not a collapse state. HAZUS mapping to D1/D2/D3 is described on PDF p. 12. No assumptions."
            ))
    return rows,[3,9,10,11,12]

def lovon2018(pdf,ps):
    """Parse Table 8 statistics for the four Lima confined-masonry classes."""
    table=[
        ("1-story formal buildings","PGA",[0.338,0.503,0.901,1.086],[0.010,0.013,0.047,0.073]),
        ("1-story informal buildings","PGA",[0.266,0.379,0.537,0.615],[0.010,0.013,0.025,0.037]),
        ("2-story formal buildings","Sa at 0.20 sec.",[0.679,1.280,1.847,2.283],[0.052,0.132,0.199,0.605]),
        ("2-story informal buildings","Sa at 0.20 sec.",[0.305,0.563,0.893,0.992],[0.006,0.021,0.080,0.107]),
    ]
    states=("Slight","Moderate","Extensive","Collapse"); rows=[]
    for building,im,means,sds in table:
        for state,mean,sd in zip(states,means,sds):
            rows.append(_rec(
                "Peru",f"confined masonry, {building}","",state,
                "Metropolitan Lima; formal/informal class preserved; DBELA and selected Peru-coast records",
                "lognormal exceedance probability (candidate; source threshold statistics)",
                "P(DS >= state | X1) = Phi(ln(X1/a)/b) [candidate mapping of source Mean/Std. deviation]",
                f"X1={im} (g)",mean,sd,"","","",
                f"a=source Mean threshold ({im}, source Table 8); b=source Std. deviation ({im}); source does not print median/beta notation; state={state}",
                "Probability of exceeding damage state",
                f"{pdf.name}, PDF p. 19, Table 8; fragility derivation PDF p. 18",
                "candidate; PDF p. 18 states that four fragility curves per building class were derived using maximum likelihood and a lognormal distribution, while Table 8 labels the columns Mean and Std. deviation. No silent conversion to median/beta was made; verify the source parameter convention before formal curve reproduction."
            ))
    return rows,[2,3,4,16,17,18,19]

def nepal_chaulagain2022(pdf,ps):
    """Parse the Nepal physical fragility parameters reproduced from Chaulagain et al. (2015)."""
    values={
        "Adobe":{"Moderate":(-3.22,0.65),"Extensive":(-1.99,0.77),"Collapse":(-1.45,0.64)},
        "Mud-bonded":{"Moderate":(-2.14,0.72),"Extensive":(-1.66,0.72),"Collapse":(-1.05,0.66)},
        "Cement-bonded":{"Moderate":(-1.82,0.68),"Extensive":(-1.06,0.67),"Collapse":(-0.62,0.72)},
        "Wooden":{"Moderate":(-1.08,0.64),"Extensive":(-0.39,0.64),"Collapse":(0.00,0.64)},
        "RCC":{"Moderate":(0.35,0.17),"Extensive":(0.85,0.20),"Collapse":(1.35,0.32)},
    }
    rows=[]
    for building,states in values.items():
        for state,(mu,sigma) in states.items():
            rows.append(_rec(
                "Nepal",f"residential {building} building","",state,
                "Nepal exposure model; physical fragility adopted from Chaulagain et al. (2015); OpenQuake risk analysis",
                "lognormal exceedance probability",
                "P(DS >= state | X1) = Phi((ln(X1)-a)/b)",
                "X1=PGA (g)",mu,sigma,"","","",
                f"a=mu, mean of ln(PGA in g), source Table 6; b=sigma, standard deviation of ln(PGA), source Table 6; original building type={building}",
                "Probability of exceedance",
                f"{pdf.name}, PDF p. 11, Table 6; physical vulnerability model description PDF pp. 9–11",
                "source table reproduced/adopted by this Nepal risk study from Chaulagain et al. (2015); damage states Moderate/Extensive/Collapse are preserved; source text explicitly describes logarithmic means and standard deviations. No assumed Slight state or zero parameter."
            ))
    return rows,[9,11,12,15,16]

def malaysia_tall2025(pdf,ps):
    """Parse Table 4 for the two tall RC models and four soil conditions."""
    models={
        "25-story tall RC model (source Table 4 label Type I)":{
            "A":((0.080,0.043),(0.161,0.087),(0.241,0.130),(0.321,0.173),(0.402,0.217)),
            "B":((0.039,0.021),(0.079,0.041),(0.118,0.062),(0.158,0.147),(0.197,0.103)),
            "C":((0.087,0.052),(0.173,0.105),(0.260,0.157),(0.347,0.190),(0.433,0.262)),
            "D":((0.012,0.058),(0.023,0.117),(0.035,0.175),(0.047,0.234),(0.058,0.292)),
        },
        "30-story tall RC model (source Table 4 label Type II)":{
            "A":((0.075,0.042),(0.156,0.072),(0.236,0.103),(0.317,0.271),(0.398,0.165)),
            "B":((0.046,0.027),(0.093,0.053),(0.139,0.080),(0.186,0.180),(0.232,0.133)),
            "C":((0.065,0.040),(0.130,0.080),(0.196,0.120),(0.261,0.155),(0.326,0.200)),
            "D":((0.015,0.092),(0.029,0.184),(0.044,0.275),(0.058,0.367),(0.073,0.459)),
        },
    }
    states=("OP","IO","DC","LS","CP"); rows=[]
    for building,soils in models.items():
        for soil,pairs in soils.items():
            for state,(mu,sigma) in zip(states,pairs):
                rows.append(_rec(
                    "Malaysia",building,"",state,
                    f"soil type {soil}; IDA; five far-field ground-motion records; source Table 4",
                    "fragility probability curve (source mu-sigma; log-space convention not stated)",
                    "P(DS >= state | X1) = Phi((X1-a)/b) [candidate reconstruction from source mu-sigma]",
                    "X1=PGA (g)",mu,sigma,"","","",
                    f"a=source mu, mean PGA at {state} drift limit (g); b=source sigma, standard deviation of PGA (g); source Table 4; soil={soil}",
                    "Probability of exceeding performance limit state",
                    f"{pdf.name}, PDF p. 11, Table 4; fragility curve discussion and Figures 6–7, PDF pp. 11–15",
                    "candidate; source states that mean and standard deviation of PGA were computed at drift-limit gridlines, but does not print the CDF equation or log base. Soil type is retained in Condition and is not used as Seismic_Level. The article has a Type I/Type II story-label inconsistency between abstract and Table 4; Table 4 labels are preserved. Verify before formal reproduction."
                ))
    return rows,[1,6,9,10,11,12,13,14,15,16]

def greece_school2023(pdf,ps):
    """Parse Table 5 for the two-direction Patras school archetype fragility curves."""
    table={
        "Longitudinal direction":[("DS0 Slight",0.503,0.219),("DS1 Moderate",1.135,0.258),("DS2 Extensive",2.433,0.355),("DS3 Near Collapse",2.977,0.387)],
        "Transverse direction":[("DS0 Slight",0.305,0.291),("DS1 Moderate",0.902,0.222),("DS2 Extensive",2.295,0.316),("DS3 Near Collapse",3.082,0.442)],
    }
    rows=[]
    for direction,states in table.items():
        for state,median,beta in states:
            rows.append(_rec(
                "Greece",f"two-storey reinforced-concrete school archetype; {direction}","",state,
                "Patras region; archetype designed to latest Eurocode 8 requirements; MSA with 20 hazard-consistent two-component records",
                "lognormal exceedance probability",
                "P(DS >= state | X1) = Phi(ln(X1/a)/b)",
                "X1=Sa(T1=0.4 s) (g)",median,beta,"","","",
                f"a=mu_DSi median Sa(T1) (g), source Table 5; b=beta_DSi dispersion, source Table 5; direction={direction}; T1=0.4 s bare frame",
                "Probability of exceeding building-level damage state",
                f"{pdf.name}, PDF p. 9, Table 5; fragility derivation PDF pp. 7–9",
                "source printed median and dispersion; DS labels preserved (DS0 Slight, DS1 Moderate, DS2 Extensive, DS3 Near Collapse); not a generic Greece building curve. No assumptions."
            ))
    return rows,[4,6,7,8,9]

def yamazaki2019_figure(pdf,ps):
    """Register figure-only Japanese curves whose equation is printed but parameters are not."""
    curves=[
        ("wooden buildings, all construction years","Figure 6","major damage"),
        ("steel (S) buildings, all construction years","Figure 6","major damage"),
        ("light-gauge steel (LS) buildings, all construction years","Figure 6","major damage"),
        ("wooden buildings, built before 1951","Figure 8a","major damage"),
        ("wooden buildings, built 1951–1981","Figure 8a","major damage"),
        ("wooden buildings, built 1982–1990","Figure 8a","major damage"),
        ("wooden buildings, built 1991–2000","Figure 8a","major damage"),
        ("wooden buildings, built 2001–2016","Figure 8a","major damage"),
    ]
    rows=[]
    for building,figure,state in curves:
        page=6 if figure=="Figure 6" else 7
        rows.append(_rec(
            "Japan",building,"",state,
            "Mashiki Town; 2016 Kumamoto earthquake; empirical damage survey; construction period/structural type stratification",
            "figure-only empirical lognormal fragility curve; numeric digitization pending",
            "P_R(PGV) = Phi((ln(PGV)-lambda)/zeta)",
            "X1=PGV (cm/s); Y=major damage ratio",
            "","","","","",
            "lambda=mean of ln(PGV); zeta=standard deviation of ln(PGV); numerical values not printed and must be digitized or obtained from source data",
            "Cumulative probability of damage equal to or higher than rank R (major)",
            f"{pdf.name}, PDF p. {page}, {figure}; equation (1) PDF p. 6",
            "figure-only candidate; the paper prints the lognormal equation and states lambda/zeta were fitted by least squares, but does not print their numerical values. Curve image is retained for later calibrated digitization; parameters intentionally blank and this record is not approved for formal curve reproduction."
        ))
    return rows,[6,7]

def giordano2020(pdf,ps):
    rows=[]; src1=f"{pdf.name}, PDF p. 4, Table 1"; src2=f"{pdf.name}, PDF p. 16, Table 2"
    table1=[("Didier et al. (2017)","Adobe",[("DS1","",""),("DS2",0.13,1.36),("DS3",0.97,1.73)]),("Didier et al. (2017)","Brick-mud URM",[("DS1","",""),("DS2",0.14,1.93),("DS3",1.26,1.96)]),("Didier et al. (2017)","Brick-cement URM",[("DS1","",""),("DS2",0.77,1.84),("DS3",1.90,0.93)]),("Didier et al. (2017)","RC Frame",[("DS1","",""),("DS2",1.67,1.73),("DS3",1.95,0.71)]),("Gautam et al. (2018)","Brick URM",[("DS1",0.13,0.38),("DS2",0.16,0.42),("DS3",0.22,0.48)]),("Gautam et al. (2018)","Stone URM",[("DS1",0.29,0.70),("DS2",0.32,0.71),("DS3",0.39,0.69)]),("Gautam et al. (2018)","RC Frame",[("DS1",0.29,0.38),("DS2",0.63,0.70),("DS3",1.29,0.83)])]
    for ref,building,states in table1:
        for state,a,b in states:
            rows.append(_rec("Nepal",building,"",state,"Nepalese residential building stock; literature empirical model","lognormal exceedance probability","P(DS >= state | X1) = Phi(ln(X1/a)/b)","X1=PGA (g)",a,b,"","","",f"a=eta median PGA (g); b=beta lognormal standard deviation; reference={ref}","Probability of exceedance",src1,"source table; DS labels preserved; blank source parameters remain blank; article notes aggregated historical data uncertainty."))
    table2=[
        ("Masonry/URML","MLE",[0.021,2.76,0.15,2.00,0.22,1.69,0.81,1.14,0.97,0.94],""),
        ("Masonry/URML","MLE n.c.",[0.006,1.71,0.11,1.71,0.22,1.71,1.67,1.71,2.59,1.71],""),
        ("Masonry/URML","B. Prior (HAZUS)",["","",0.13,0.64,0.17,0.64,0.26,0.64,0.37,0.64],"pre-code"),
        ("Masonry/URML","B. Posterior",["","",0.14,0.97,0.18,0.93,0.39,0.82,0.55,0.76],"pre-code"),
        ("RC Frame/C3L","B. Prior (HAZUS)",["","",0.12,0.64,0.17,0.64,0.26,0.64,0.44,0.64],"low-code"),
        ("RC Frame/C3L","B. Posterior",["","",0.19,1.08,0.27,1.04,0.77,0.88,1.13,0.84],"low-code"),
        ("Steel Frame/S3","B. Prior (HAZUS)",["","",0.10,0.64,0.13,0.64,0.20,0.64,0.38,0.64],"low-code"),
        ("Steel Frame/S3","B. Posterior",["","",0.09,1.16,0.12,1.24,0.46,1.12,1.13,1.07],"low-code"),
        ("Timber Frame/W1","B. Prior (HAZUS)",["","",0.18,0.64,0.29,0.64,0.51,0.64,0.77,0.64],"pre-code"),
        ("Timber Frame/W1","B. Posterior",["","",0.17,1.30,0.32,1.25,1.01,1.21,1.36,0.98],"pre-code")]
    for building,method,values,level in table2:
        for j,state in enumerate(("DS1","DS2","DS3","DS4","DS5")):
            a,b=values[j*2:j*2+2]
            rows.append(_rec("Nepal",building,level,state,f"SIDA 2015 Nepal school damage data; {method}","lognormal exceedance probability","P(DS >= state | X1) = Phi(ln(X1/a)/b)","X1=PGA (g)",a,b,"","","",f"a=eta median PGA (g); b=beta lognormal standard deviation; method={method}","Probability of exceedance",src2,"source table parameter; DS1–DS5 labels preserved; prior/posterior distinction preserved; missing DS1 in HAZUS prior is source blank, not zero."))
    return rows,[4,14,15,16,17]

def essd2024(pdf,ps):
    return [_rec("Japan","Noto Peninsula earthquake affected buildings (aggregated)","","aggregated building damage","2024 Noto Peninsula; non-inundated/non-fire/non-landslide subset; seismic shaking assumed as sole cause","lognormal empirical fragility","F_X(X1) = Phi((ln(X1)-a)/b)","X1=PGV (cm/s); aggregated damage response",6.436,0.9869,"","","","a=mu mean of ln(PGV); b=sigma log-space standard deviation; OLS fit","Aggregated damage probability",f"{pdf.name}, PDF p. 18, Eq. (1) and text; Figure 12 p. 19","source printed parameters; not damage-state-specific; paper explicitly states the shaking-only assumption for this subset; no assumptions added.")],[17,18,19]

def yamaguchi2000(pdf,ps):
    """Parse the printed Japanese building fragility parameter tables 3 and 4."""
    rows=[]; types=[("W","average"),("W","≤1951"),("W","1952–61"),("W","1962–71"),("W","1972–81"),("W","1982–94"),("WP","all periods"),("RC","average"),("RC","≤1971"),("RC","1972–81"),("RC","1982–94"),("S","all periods"),("LSP","all periods")]
    table3=[[6.76,.613,.992,4.60,.538,.992,4.77,.568,.992,6.35,.500,.981],[6.38,.571,.988,4.27,.501,.988,4.42,.529,.988,6.05,.477,.988],[6.62,.585,.977,4.48,.525,.978,4.64,.554,.978,6.25,.600,.939],[6.67,.561,.985,4.52,.493,.985,4.69,.520,.985,6.29,.468,.986],[6.93,.547,.972,4.75,.480,.973,4.93,.507,.972,6.51,.455,.974],[7.58,.682,.924,5.32,.599,.923,5.53,.632,.924,7.06,.574,.917],[8.05,1.01,.940,5.74,.891,.938,5.97,.939,.939,7.49,.880,.921],[8.03,.970,.932,5.71,.849,.931,5.94,.898,.931,7.35,.750,.904],[7.75,.907,.936,5.46,.789,.940,5.68,.833,.940,7.22,.798,.912],[7.94,.996,.898,5.64,.876,.898,5.86,.925,.898,7.36,.847,.895],[10.5,1.97,.590,7.89,1.73,.589,8.24,1.83,.589,9.56,1.68,.576],[7.90,.939,.980,5.60,.824,.980,5.83,.870,.980,7.32,.781,.980],[8.61,1.20,.930,6.23,1.05,.932,6.49,1.11,.931,7.88,.984,.940]]
    table4=[[6.33,.622,.992,4.22,.546,.992,4.37,.576,.992,6.00,.503,.991],[5.97,.673,.978,3.91,.591,.978,4.04,.624,.978,5.71,.562,.978],[6.18,.616,.972,4.08,.555,.970,4.22,.585,.971,5.79,.640,.923],[6.22,.557,.983,4.12,.489,.983,4.27,.516,.983,5.92,.465,.984],[6.41,.508,.978,4.30,.446,.978,4.45,.471,.978,6.08,.422,.981],[6.94,.718,.983,4.76,.629,.983,4.94,.665,.983,6.52,.595,.982],[7.47,.839,.985,5.00,.737,.985,5.20,.778,.985,6.74,.698,.985],[7.34,.912,.942,5.11,.798,.942,5.31,.844,.942,6.83,.723,.911],[7.19,.947,.921,4.97,.825,.923,5.16,.871,.923,6.72,.821,.895],[7.29,1.01,.888,5.06,.887,.887,5.26,.936,.887,6.82,.859,.877],[8.05,1.18,.798,5.73,1.04,.797,5.97,1.10,.798,7.45,.989,.792],[7.18,.894,.970,4.97,.784,.969,5.16,.828,.970,6.72,.744,.969],[7.45,.852,.951,5.20,.747,.951,5.41,.789,.951,6.93,.705,.952]]
    ims=[("PGA","cm/s²"),("PGV","cm/s"),("SI","cm/s"),("JMA intensity","index")]
    for damage,data,table_no in (("Heavy damage",table3,3),("Heavy + Moderate damage",table4,4)):
        for (typ,period),values in zip(types,data):
            for j,(im,unit) in enumerate(ims):
                a,b,r2=values[j*3:j*3+3]; building={"W":"wood-frame (W)","WP":"wooden-prefabricated (WP)","RC":"reinforced-concrete (RC)","S":"steel-frame (S)","LSP":"light-gauge steel-prefabricated (LSP)"}[typ]
                rows.append(_rec("Japan",building,"",damage,f"Nishinomiya City; construction period={period}; 1995 Kobe damage survey","lognormal exceedance probability", "P(DS >= damage | X1) = Phi((ln(X1)-a)/b)",f"X1={im} ({unit})",a,b,"","","",f"a=lambda, mean of ln(X1) in source units; b=zeta, standard deviation of ln(X1), dimensionless; r={r2} goodness-of-fit; source Table {table_no}","Probability of damage equal to or greater than state",f"{pdf.name}, PDF p. 5, Table {table_no}","source printed parameter; damage definitions and construction-period labels preserved; source units are not converted; no assumptions.") )
    return rows,[4,5,6,7]

def adminasce2025(pdf,ps):
    """Parse the two printed concrete-strength fragility sets in the Indonesian house study."""
    states=("Slight","Moderate","Extensive","Complete"); values={"25 MPa":((1.731,.131),(2.473,.131),(3.190,.139),(5.344,.150)),"15 MPa":((2.083,.131),(2.975,.131),(3.882,.139),(6.601,.150))}; rows=[]
    for strength,pairs in values.items():
        for state,(a,b) in zip(states,pairs):
            rows.append(_rec("Indonesia","Permanent simple house, Type 36, reinforced concrete","",state,f"f'c={strength}; Padang simple-house model","lognormal exceedance probability","P(DS >= state | X1) = Phi(ln(X1/a)/b)","X1=Sd spectral displacement (cm)",a,b,"","","",f"a=Sd_{state} median (cm); b=beta_{state} lognormal standard deviation (dimensionless); concrete compressive strength={strength}","Probability of exceedance",f"{pdf.name}, PDF p. 4, Table 3", "source printed parameter; HAZUS 2003 performance states; source text reports 50% crossing approximately at Sd=a; no assumptions."))
    return rows,[3,4]

def algeria_eas2022(pdf,ps):
    """Parse the printed Algeria RC-frame fragility parameters in Table 9."""
    states=("Slight","Moderate","Extensive","Complete")
    values={
        "3-Story":((0.068,0.334),(0.099,0.334),(0.201,0.334),(0.410,0.334)),
        "4-Story":((0.046,0.328),(0.066,0.328),(0.128,0.328),(0.250,0.328)),
        "5-Story":((0.044,0.326),(0.060,0.326),(0.113,0.326),(0.212,0.326)),
        "6-Story":((0.041,0.323),(0.056,0.323),(0.105,0.323),(0.195,0.323)),
    }
    rows=[]
    for frame,pairs in values.items():
        for state,(mu,beta) in zip(states,pairs):
            rows.append(_rec(
                "Algeria",f"RC private construction {frame}","",state,
                "Northern Algeria; built after 2003; without complying with seismic regulation; 2D RC frame with unreinforced brick infill walls",
                "lognormal exceedance probability",
                "P(DS >= state | X1) = Phi(ln(X1/a)/b)",
                "X1=A zone acceleration coefficient (dimensionless; RPA 99/2003)",
                mu,beta,"","","",
                f"a=mu median X1 (dimensionless); b=beta log-space dispersion; source Table 9; HAZUS state={state}",
                "Probability of exceedance",
                f"{pdf.name}, PDF p. 10, Table 9",
                "source printed parameter; Eq. (6) defines P(D>=Dk|IM)=Phi(ln(IM/mu)/beta); state labels preserved; Seismic_Level is blank because A is the intensity measure, not a site category; no assumptions."
            ))
    return rows,[3,8,10,11,12]

def haiti_wcee2024(pdf,ps):
    """Parse the MLE medians and dispersion in the Haiti WCEE 2024 Table 3."""
    states=("minor damage","moderate damage","extensive damage","complete damage")
    groups={
        "All buildings":([0.14,0.24,0.42,0.66],0.68),
        "All confined masonry":([0.19,0.31,0.54,0.67],0.69),
        "All traditional":([0.10,0.16,0.34,0.66],0.68),
        "URML buildings (pre-code)":([0.13,0.17,0.26,0.37],0.64),
        "URMM buildings (pre-code)":([0.09,0.13,0.21,0.38],0.64),
    }
    rows=[]
    for building,(medians,beta) in groups.items():
        for state,median in zip(states,medians):
            rows.append(_rec(
                "Haiti",building,"",state,
                "Southern Haiti; post-14 August 2021 M6.87 earthquake visual survey; 127275 buildings used for fragility estimates",
                "lognormal exceedance probability",
                "P(DS >= state | X1) = Phi(ln(X1/a)/b)",
                "X1=PGA (g)",median,beta,"","","",
                f"a=median PGA for {state} (g); b=common lognormal standard deviation; Table 3 MLE values",
                "Probability of exceeding damage state",
                f"{pdf.name}, PDF p. 9, Table 3; Eq. (4), PDF p. 6",
                "source printed MLE parameter; four damage-state labels retain the table wording (minor, moderate, extensive, complete); the paper states b is unique by typology and common across states; no assumptions."
            ))
    return rows,[5,6,9,10,11,12]

def bnzsee2025(pdf,ps):
    """Parse the Combined fragility parameters printed in BNZSEE Table 6.

    The paper is a multi-study experimental/numerical database of masonry-
    infilled RC frames rather than a country-specific building-stock study.
    Country is therefore intentionally blank; the folder name is not used as
    a proxy for research-object country.
    """
    states=("DS1","DS2","DS3","DS4")
    values={
        "Non-ductile": {
            "Low": ((0.12,0.38),(0.45,0.26),(1.04,0.29),(2.09,0.30)),
            "Medium": ((0.09,0.33),(0.31,0.37),(0.81,0.48),(1.53,0.49)),
            "High": ((0.09,0.25),(0.30,0.32),(0.42,0.28),(0.63,0.34)),
        },
        "Ductile": {
            "Low": ((0.15,0.19),(0.48,0.24),(1.60,0.18),(3.32,0.18)),
            "Medium": ((0.11,0.11),(0.42,0.09),(1.69,0.06),(3.36,0.09)),
        },
    }
    definitions={
        "DS1":"minor separation of IM from frame; diagonal IM cracking; limited crushing at upper corners",
        "DS2":"increased crushing at upper corners; start of structural damage; diagonal shear cracking of exterior-frame RC members",
        "DS3":"extensive IM cracking; falling masonry bricks; out-of-plane bulging; partial IM failure; heavier frame-member damage",
        "DS4":"near-total IM failure; RC-member shear failure",
    }
    rows=[]
    for frame,by_strength in values.items():
        for strength,pairs in by_strength.items():
            for state,(median,dispersion) in zip(states,pairs):
                rows.append(_rec(
                    "", "single-storey single-bay fully filled masonry-infilled RC frame (IM-RC)", "", state,
                    f"{frame} RC frame; {strength} masonry compressive-strength class; combined experimental and numerical dataset; DS definition={definitions[state]}",
                    "lognormal conditional fragility probability",
                    "F_i(delta)=Phi(ln(delta_i/theta_i,ds)/beta_ds); program form P(DS >= state | X1)=Phi(ln(X1/a)/b)",
                    "X1=in-plane drift ratio delta_i (%)",
                    median, dispersion, "", "", "",
                    f"a=theta_i,ds median drift ratio (%); b=beta_i,ds logarithmic standard deviation (dimensionless); original state={state}; masonry class: Low <=5 MPa, Medium >5 and <=15 MPa, High >15 MPa",
                    "Conditional probability of reaching the specified damage state",
                    f"{pdf.name}, PDF p. 15, Table 6 Combined; Eq. (3), PDF p. 12",
                    "source printed Combined parameters; DS1-DS4 and source damage definitions retained; beta_ds includes record uncertainty and the paper assumes beta_ds,u=0.10 in Eq. (5); Country intentionally blank because the paper aggregates 157 experimental datasets from 50 studies and 320 numerical cases rather than a single national building stock; the journal/folder is New Zealand but is not the research-object country; numerical frame detailing is discussed in a Sri Lankan context, but the aggregated curve is not assigned to Sri Lanka; no assumptions added."
                ))
    if len(rows)!=20: raise RuntimeError(f"Expected 20 BNZSEE Combined rows, parsed {len(rows)}")
    return rows,[3,5,12,13,14,15]

def iran_highrise2022(pdf,ps):
    """Parse the researcher-used lognormal comparison row in Iranian Table 5.

    Table 5 supplies u and sigma for the three performance-level/story
    combinations used in Fig. 10.  The paper also evaluates other fitted
    distributions; these rows are explicitly labelled comparison candidates.
    """
    states=("IO","LS","CP")
    stories=(30,25,20)
    values={
        "IO":(-1.30,0.222),
        "LS":(-0.50,0.360),
        "CP":(0.765,0.460),
    }
    # Table 5 columns are 20,25,30 stories for each performance level.
    table={
        "IO": {20:(-1.30,0.222),25:(-1.71,0.312),30:(-2.04,0.336)},
        "LS": {20:(-0.16,0.305),25:(-0.50,0.360),30:(-0.70,0.259)},
        "CP": {20:(0.765,0.460),25:(0.583,0.340),30:(0.248,0.310)},
    }
    rows=[]
    for state in states:
        for nstorey in stories:
            u,sigma=table[state][nstorey]
            rows.append(_rec(
                "Iran", f"high-rise steel dual-system frame ({nstorey}-storey; special moment frame with eccentrically braced frame)",
                "very high seismic hazard area", state,
                f"residential model designed to Iranian Standard 2800 and national provisions; soil type 2; IDA; source Table 5 lognormal comparison parameters",
                "lognormal exceedance probability",
                "P(D=EDP > C=EDP_i | X1)=Phi((ln(X1)-a)/b)",
                "X1=Sa(T1,5%) spectral acceleration (g); ln()=natural logarithm",
                u, sigma, "", "", "",
                "a=u mean/location parameter of ln(Sa) (source units; not converted to exp median); b=sigma scale/standard deviation of ln(Sa) (dimensionless); original performance level and story count preserved",
                "Probability of exceeding the performance-level threshold",
                f"{pdf.name}, PDF p. 9, Eq. (12); PDF p. 10, Table 5",
                "candidate comparison record; source calls lognormal the distribution used by researchers and compares it with fitted alternatives; Table 6 reports the best fitted distribution may differ; no fitted-distribution substitution or parameter conversion; no assumptions."
            ))
    if len(rows)!=9: raise RuntimeError(f"Expected 9 Iranian Table 5 lognormal rows, parsed {len(rows)}")
    return rows,[4,6,7,9,10,11]

def report0718(pdf,ps):
    """Parse the conventional fragility parameters in Report07-18 Tables C.1-C.3.

    Tables C.2/C.3 give ln(a1), a2 and beta_tot for a regression relationship;
    Table C.1 gives the damage-state spectral-displacement threshold.  The
    fixed schema stores those four source values in a,b,c,d and keeps the
    exact Eq. (4.4) relationship in Function_Expression.
    """
    text={p:t for p,t in ps}
    codes=("Pre-Code","Low Code","Moderate Code","High Code")
    states=("Slight","Moderate","Extensive","Complete")
    # C.1 is split across PDF pages 175-176 and has four code blocks of four thresholds.
    threshold_rows={}
    row_re=re.compile(rf"^\s*([A-Z0-9]+)\s+((?:{NUM}\s+){{15}}{NUM})\s*$")
    for page in (175,176):
        for raw in text.get(page,"").splitlines():
            m=row_re.match(" ".join(raw.split()))
            if m:
                threshold_rows[m.group(1)]=[float(x) for x in re.findall(NUM,m.group(2))]
    # C.2 lowlands and C.3 uplands are each split over two PDF pages.
    param_rows={"lowlands":{},"uplands":{}}
    for profile,page_pair in (("lowlands",(176,177)),("uplands",(178,179))):
        for page in page_pair:
            for raw in text.get(page,"").splitlines():
                m=re.match(rf"^\s*([A-Z0-9]+)\s+((?:{NUM}\s+){{11}}{NUM})\s*$"," ".join(raw.split()))
                if m:
                    param_rows[profile][m.group(1)]=[float(x) for x in re.findall(NUM,m.group(2))]
    if not param_rows["lowlands"] or not param_rows["uplands"]:
        raise RuntimeError("Report07-18 Tables C.2/C.3 parameter rows not found")
    rows=[]
    for profile,table_no in (("lowlands",2),("uplands",3)):
        for building,values in param_rows[profile].items():
            thresholds=threshold_rows.get(building,[])
            if len(thresholds)!=16: continue
            for code_index,code in enumerate(codes):
                triplet=values[code_index*3:code_index*3+3]
                # The report prints zero blocks for unavailable type/code combinations.
                if len(triplet)!=3 or all(v==0 for v in triplet): continue
                ln_a1,a2,beta_tot=triplet
                for state_index,state in enumerate(states):
                    threshold=thresholds[code_index*4+state_index]
                    if threshold==0: continue
                    rows.append(_rec(
                        "United States",f"HAZUS {building}",code,state,
                        f"{profile} soil profile; Central/Eastern United States (CEUS) analytical population fragility; HAZUS capacity diagrams",
                        "conventional fragility relationship; lognormal exceedance probability",
                        "P(DS >= state | X1) = 1 - Phi((ln(d) - (a + b*ln(X1)))/c)",
                        "X1=PGA/GMI (g); d=limit-state spectral displacement threshold (in); ln()=natural logarithm",
                        ln_a1,a2,beta_tot,threshold,"",
                        "a=ln(a1) regression intercept; b=a2 regression slope; c=beta_tot as printed; d=Table C.1 spectral-displacement threshold; e=not used",
                        "Probability of exceeding the selected limit state",
                        f"{pdf.name}, PDF p. 86 Eq. (4.4); PDF pp. 175–179 Tables C.1 and C.{table_no}",
                        "source printed values; Table C.2/C.3 parameters are combined with the corresponding Table C.1 threshold; building code labels and Slight/Moderate/Extensive/Complete states are retained; source zero blocks for unavailable combinations are omitted, not converted to zero parameters; Country=United States is supported by the report's USA/Central USA/CEUS scope and HAZUS context; the Indonesia folder is only the download/archive location; no assumptions."
                    ))
    if not rows: raise RuntimeError("No Report07-18 conventional fragility rows parsed")
    return rows,[86,175,176,177,178,179]

def batch_extractors():
    return {"buildings-13-01361.pdf":buildings2023,"9. seismic vulnerability assessment of hospital building.pdf":hospital_hazus,"10.2478_cee-2023-0039.pdf":awchat2023,"jurnal+no.14.pdf":jurnal2024,"giordano2020_article_empiricalseismicfragilitymodel.pdf":giordano2020,"essd-2024-363.pdf":essd2024,"wcee2000_2451yamaguchi.pdf":yamaguchi2000,"adminasce,+360-364.pdf":adminasce2025,"eas2201003.pdf":algeria_eas2022,"wcee2024-miyamoto-haiti-fragility.pdf":haiti_wcee2024,"report07-18.pdf":report0718,"6_bnzsee1718_raheem+et+al_fragility+of+masonry+infilled+frames_with+supplementary+data.pdf":bnzsee2025,"doi_ 10.22034_22.2.16.pdf":iran_highrise2022,"seismic+fragility.pdf":australia_nz_2020,"a lovon_tarque_2018.pdf":lovon2018,"nhess-22-3211-2022.pdf":nepal_chaulagain2022,"6035-article text-31620-1-10-20250502.pdf":malaysia_tall2025,"53_2023_ijdrr_90_103610.pdf":greece_school2023,"2019pcee_yamazaki.pdf":yamazaki2019_figure}

def _row_key(rec):
    return tuple("" if rec.get(k) is None else str(rec.get(k)) for k in FIELDS)

def _existing_workbook_rows(path):
    """Read fixed-schema rows for deduplication; this is read-only inspection."""
    from openpyxl import load_workbook
    wb=load_workbook(path,read_only=True,data_only=False)
    try:
        ws=wb.active; header=[ws.cell(1,c).value for c in range(1,len(FIELDS)+1)]
        if header!=FIELDS: raise RuntimeError(f"Fixed header mismatch in {path}: {header}")
        for row in ws.iter_rows(min_row=2,max_col=len(FIELDS),values_only=True):
            yield tuple("" if v is None else str(v) for v in row)
    finally: wb.close()

def _historical_state(out,base):
    rows=set(); processed_paths=set(); processed_names=set()
    candidates=[]
    if base.exists(): candidates.append(base)
    candidates.extend(p for p in sorted(out.glob("fragility_library*.xlsx")) if p.exists() and "_backup_" not in p.name)
    for path in dict.fromkeys(candidates):
        try:
            for row in _existing_workbook_rows(path):
                rows.add(row); source=row[FIELDS.index("Source")]; notes=row[FIELDS.index("Notes")]
                for raw in re.findall(r"PDF_Path=([^;]+)",notes): processed_paths.add(str(Path(raw.strip()).resolve()).lower())
                for match in re.findall(r"(?i)([^,;\s]+\.pdf)",str(source)):
                    processed_names.add(Path(match).name.lower())
        except Exception as e:
            print(f"WARN could not inspect historical workbook {path}: {e}")
    return rows,processed_paths,processed_names

def _safe_archive_label(value):
    value=str(value or "").strip()
    if not value: return "MultiCountry_Unassigned"
    value=re.sub(r"[<>:\"/\\|?*]+","_",value)
    value=re.sub(r"\s+","_",value).strip("._")
    return value or "MultiCountry_Unassigned"

def _archive_scope_label(records):
    countries=sorted({str(r.get("Country") or "").strip() for r in records if str(r.get("Country") or "").strip()})
    if len(countries)==1: return countries[0]
    if len(countries)>1: return "Mixed_Country_Scope"
    return "MultiCountry_Unassigned"

def archive_source_pdf(pdf,country,archive_root):
    """Copy a processed source into a country-labelled archive without moving the original."""
    source=Path(pdf)
    if not source.exists(): return ""
    folder=Path(archive_root)/_safe_archive_label(country); folder.mkdir(parents=True,exist_ok=True)
    stem=f"{_safe_archive_label(country)}__{source.name}"
    dest=folder/stem
    if dest.exists() and digest(dest)!=digest(source): dest=folder/f"{_safe_archive_label(country)}__{source.stem}__{digest(source)[:10]}{source.suffix}"
    if not dest.exists(): shutil.copy2(source,dest)
    return str(dest.resolve())

def _with_pdf_path(records,pdf,archive_path=""):
    path=str(Path(pdf).resolve())
    out=[]
    for rec in records:
        r=dict(rec); notes=str(r.get("Notes") or "").rstrip("; ")
        additions=[f"PDF_Path={path}"]
        if archive_path: additions.append(f"Country_Archive_Path={archive_path}")
        r["Notes"]=(notes+"; " if notes else "")+"; ".join(additions)
        out.append(r)
    return out

def _screen_pdf(pdf):
    """Screen unscoped PDFs without creating records or executing document text."""
    ps=pages(pdf); hits=[]
    pattern=re.compile(r"fragility|vulnerability|curve|damage state|易损|脆弱|曲线|损伤状态",re.I)
    for p,t in ps:
        if pattern.search(t or ""): hits.append(p)
    if hits:
        return {"status":"relevant_not_structured","pages":hits,"reason":"relevant terms found; no safe scoped extractor; requires figure/table visual review"}
    return {"status":"not_relevant_or_no_native_text","pages":[],"reason":"no relevant native-text hit; scanned without OCR"}

def incremental(args):
    """Scan a folder, add only new scoped records, and emit a dated export manifest."""
    if not deps(): raise SystemExit("Required dependency missing")
    input_root=Path(args.input).resolve(); out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    if args.base: base=Path(args.base).resolve()
    else:
        snapshots=[p for p in out.glob("fragility_library_*.xlsx") if "_backup_" not in p.name]
        base=max(snapshots,key=lambda p:p.stat().st_mtime) if snapshots else out/"fragility_library.xlsx"
    if not input_root.is_dir(): raise RuntimeError(f"Input folder not found: {input_root}")
    if not base.exists(): raise RuntimeError(f"Base workbook not found: {base}")
    stamp=args.stamp or time.strftime("%Y%m%d_%H%M%S")
    rows,processed_paths,processed_names=_historical_state(out,base); known=batch_extractors(); new_keys=set(rows); records=[]; report=[]
    include={str(x).strip().lower() for x in (args.include or []) if str(x).strip()}
    evidence=out/"evidence"/f"batch_{stamp}"; reviews=out/"reviews"/f"batch_{stamp}"; cache_root=out/"cache"/f"batch_{stamp}"
    for pdf in sorted(input_root.rglob("*.pdf"),key=lambda p:str(p).lower()):
        full=str(pdf.resolve()); name=pdf.name.lower()
        if include and name not in include and full.lower() not in include:
            continue
        if full.lower() in processed_paths or name in processed_names:
            report.append({"pdf":full,"status":"already_processed","added_records":0,"reason":"full path or source filename already exists in historical workbook"}); continue
        if name in known:
            try:
                ps=pages(pdf); parsed=known[name](pdf,ps); recs,focus=parsed if isinstance(parsed,tuple) else (parsed,[]); archive_country=_archive_scope_label(recs); archive_file=archive_source_pdf(pdf,archive_country,out/"source_archive_by_country"); recs=_with_pdf_path(recs,pdf,archive_file)
                added=[]
                for rec in recs:
                    key=_row_key(rec)
                    if key not in new_keys: new_keys.add(key); records.append(rec); added.append(rec)
                ev=render(pdf,focus,evidence); item={"pdf":full,"scope":f"scoped extractor for {name}","review_pages":focus,"archive_country":archive_country}; reviews.mkdir(parents=True,exist_ok=True); write_docx(item,ps,added,ev,reviews)
                cdir=cache_root/digest(pdf); cdir.mkdir(parents=True,exist_ok=True); (cdir/"records.json").write_text(json.dumps(added,ensure_ascii=False,indent=2),encoding="utf-8")
                report.append({"pdf":full,"status":"added_structured","added_records":len(added),"evidence_pages":focus,"extractor":known[name].__name__})
            except Exception as e:
                report.append({"pdf":full,"status":"extract_error","added_records":0,"reason":repr(e)})
            continue
        try: result=_screen_pdf(pdf); result.update({"pdf":full,"added_records":0}); report.append(result)
        except Exception as e: report.append({"pdf":full,"status":"unreadable","added_records":0,"reason":repr(e)})
    records_path=out/f"batch_records_{stamp}.json"; report_path=out/f"batch_report_{stamp}.json"; checks=out/f"_checks_{stamp}"; curve_checks(records,checks)
    records_path.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding="utf-8"); report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    xlsx=out/f"fragility_library_{stamp}.xlsx"; manifest={"base_workbook":str(base),"records":str(records_path),"report":str(report_path),"output_xlsx":str(xlsx),"timestamp":stamp,"input_root":str(input_root),"record_count":len(records)}
    manifest_path=out/f"batch_manifest_{stamp}.json"; manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    counts={}
    for item in report: counts[item["status"]]=counts.get(item["status"],0)+1
    print(json.dumps({"manifest":str(manifest_path),"records":len(records),"status_counts":counts},ensure_ascii=False))
    return manifest_path

def write_docx(item,ps,recs,ev,out):
    from docx import Document
    from docx.shared import Inches
    d=Document(); d.add_heading("Fragility pipeline review packet",0); d.add_paragraph(f"Source PDF: {item['pdf']}\nRecords: {len(recs)}\nSource PDF is preserved; this packet is a readable verification aid.")
    d.add_heading("Scope and evidence",1); d.add_paragraph(item.get("scope","")); d.add_paragraph("Evidence images: "+("; ".join(ev) if ev else "not rendered"))
    for image in ev:
        try: d.add_picture(image,width=Inches(6.2)); d.add_paragraph(f"Original PDF page image: {image}")
        except Exception as e: d.add_paragraph(f"Could not embed evidence image {image}: {e}")
    d.add_heading("Candidate records",1); t=d.add_table(rows=1,cols=7); t.style="Table Grid"
    for c,h in zip(t.rows[0].cells,["Damage","Condition","Function","Expression","a–e","Source","Notes"]): c.text=h
    for r in recs:
        vals=[r["Damage_State"],r["Condition"],r["Function_Type"],r["Function_Expression"],"; ".join(str(r[x]) for x in "abcde" if r[x] != ""),r["Source"],r["Notes"]]
        for c,v in zip(t.add_row().cells,vals): c.text=str(v)
    d.add_heading("Page-numbered extracted text",1); nm=Path(item["pdf"]).name.lower(); wanted=set(item.get("review_pages",[])) or ({30,31,6} if nm.startswith("nhess-2018") else ({13,16,17,18} if nm.startswith("nhess-2022") else {7,8,9}))
    for p,tx in ps:
        if p in wanted: d.add_heading(f"PDF page {p}",2); d.add_paragraph(tx[:12000])
    d.add_heading("Review checklist",1)
    for x in ["Original page image checked for equations/tables","Damage-state meaning and probability type confirmed","Units, percent/g and log base checked","Missing/derived/assumed values marked","Curve completeness and monotonic trend checked","Only approved records may be appended"]: d.add_paragraph("☐ "+x)
    prefix=_safe_archive_label(item.get("archive_country",""))
    d.save(out/(prefix+"__"+Path(item["pdf"]).stem+"_review.docx"))

def curve_checks(recs,out):
    """Independent standard-library checks; no eval of document text."""
    import csv
    checks=[]; points=[]
    phi=lambda z:0.5*(1+math.erf(z/math.sqrt(2)))
    for i,r in enumerate(recs,1):
        check={"record":i,"damage_state":r.get("Damage_State"),"source":r.get("Source"),"status":"not_run","probability_range":"not_run","trend":"not_run","notes":""}
        expr=str(r.get("Function_Expression") or "")
        try: a=float(r.get("a")); b=float(r.get("b"))
        except (TypeError,ValueError): a=b=None
        if "beta_tot" in expr:
            check["status"]="needs_review"; check["notes"]="beta_tot is missing or not independently specified; curve not generated."
        elif a is None or b is None or b<=0:
            check["status"]="needs_review"; check["notes"]="A complete numeric a,b pair is not available; curve not generated."
        else:
            ln_mu="ln(X1)-a" in expr or "ln(X1) - a" in expr
            normal_mu="X1-mu" in expr or "X1 - mu" in expr
            center=math.exp(a) if ln_mu and a<50 else a
            if center<=0: check["status"]="fail"; check["notes"]="Non-positive curve center; no curve generated."
            else:
                xs=[center*(0.1+j*0.1) for j in range(100)]; ys=[]
                for x in xs:
                    y=phi((math.log(x)-a)/b) if ln_mu else (phi((x-a)/b) if normal_mu else phi(math.log(x/a)/b))
                    ys.append(y); points.append({"record":i,"x":x,"probability":y,"damage_state":r.get("Damage_State"),"building":r.get("Building_Type"),"condition":r.get("Condition")})
                check["status"]="pass"; check["probability_range"]="pass" if all(0<=y<=1 for y in ys) else "fail"; check["trend"]="pass" if all(ys[j+1]>=ys[j]-1e-12 for j in range(len(ys)-1)) else "fail"; check["notes"]="Phi evaluated independently with math.erf; center x gives approximately 0.5 under the recorded expression; units are not silently converted."
        checks.append(check)
    checkdir=Path(out); checkdir.mkdir(parents=True,exist_ok=True)
    (checkdir/"curve_checks.json").write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding="utf-8")
    with (checkdir/"review_curves.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=["record","x","probability","damage_state","building","condition"]); w.writeheader(); w.writerows(points)

def append_excel(workbook,recs,dry=False):
    from openpyxl import load_workbook
    path=Path(workbook); lock=path.with_suffix(path.suffix+".lock")
    try: fd=os.open(str(lock),os.O_CREAT|os.O_EXCL|os.O_WRONLY); os.write(fd,str(os.getpid()).encode()); os.close(fd)
    except FileExistsError: raise RuntimeError(f"Workbook lock exists: {lock}")
    try:
        wb=load_workbook(path); ws=wb.active; actual=[ws.cell(1,c).value for c in range(1,len(FIELDS)+1)]
        if actual!=FIELDS: raise RuntimeError(f"Fixed header mismatch. Found {actual}; expected {FIELDS}")
        if dry: print(f"DRY RUN: {len(recs)} row(s), workbook unchanged"); return
        backup=path.with_name(path.stem+f"_backup_{time.strftime('%Y%m%d_%H%M%S')}{path.suffix}"); shutil.copy2(path,backup); existing={tuple(str(ws.cell(r,c).value or "") for c in range(1,len(FIELDS)+1)) for r in range(2,ws.max_row+1)}; added=0
        for rec in recs:
            vals=[json.dumps(rec.get(k),ensure_ascii=False) if isinstance(rec.get(k),(list,dict)) else rec.get(k,"") for k in FIELDS]; key=tuple(str(v or "") for v in vals)
            if key not in existing: ws.append(vals); existing.add(key); added+=1
        wb.save(path); print(f"Appended {added} new row(s); backup={backup}")
    finally:
        try: lock.unlink()
        except Exception: pass

def run(args):
    if not deps(): raise SystemExit("Required dependency missing")
    man=json.loads(Path(args.manifest).read_text(encoding="utf-8")); out=Path(args.out); out.mkdir(parents=True,exist_ok=True); allrecs=[]
    for item in man["papers"]:
        pdf=Path(item["pdf"]); cache=out/"cache"/digest(pdf); cache.mkdir(parents=True,exist_ok=True); ps=pages(pdf); name=pdf.name.lower();
        if name in batch_extractors():
            parsed=batch_extractors()[name](pdf,ps)
            recs,focus=parsed if isinstance(parsed,tuple) else (parsed,[])
        elif name=="nhess-2018-254.pdf": recs=nhess(pdf,ps); focus=[30,31,6]
        elif name=="nhess-2022-73-manuscript-version2.pdf": recs,focus=nhess2022_figure10(item,pdf,ps); focus=[13,16,17,18]
        elif name=="cjge20221053.pdf": recs=cjge(pdf,ps); focus=[8,9]
        else: recs,focus=curve_image_candidates(item,pdf,ps)
        archive_country=_archive_scope_label(recs); archive_file=archive_source_pdf(pdf,archive_country,out/"source_archive_by_country"); recs=_with_pdf_path(recs,pdf,archive_file); item=dict(item); item["archive_country"]=archive_country
        ev=render(pdf,focus,out/"evidence"); write_docx(item,ps,recs,ev,out); (cache/"records.json").write_text(json.dumps(recs,ensure_ascii=False,indent=2),encoding="utf-8"); allrecs.extend(recs); print(f"{pdf.name}: {len(recs)} candidate record(s)")
    (out/"records.json").write_text(json.dumps(allrecs,ensure_ascii=False,indent=2),encoding="utf-8"); curve_checks(allrecs,out); print(f"Total candidate records: {len(allrecs)}")
    if args.workbook: append_excel(args.workbook,allrecs,args.dry_run)

def main():
    p=argparse.ArgumentParser(); s=p.add_subparsers(dest="cmd",required=True); s.add_parser("check-deps"); r=s.add_parser("run"); r.add_argument("--manifest",required=True); r.add_argument("--out",required=True); r.add_argument("--workbook"); r.add_argument("--dry-run",action="store_true"); a=s.add_parser("append"); a.add_argument("--workbook",required=True); a.add_argument("--records",required=True); a.add_argument("--dry-run",action="store_true"); b=s.add_parser("incremental"); b.add_argument("--input",required=True); b.add_argument("--out",required=True); b.add_argument("--base"); b.add_argument("--stamp"); b.add_argument("--include",action="append",help="optional PDF basenames or full paths to rescan; omit to scan the full input tree"); x=p.parse_args()
    if x.cmd=="check-deps": raise SystemExit(0 if deps() else 1)
    if x.cmd=="run": run(x)
    if x.cmd=="append": append_excel(x.workbook,json.loads(Path(x.records).read_text(encoding="utf-8")),x.dry_run)
    if x.cmd=="incremental": incremental(x)
if __name__=="__main__": main()
