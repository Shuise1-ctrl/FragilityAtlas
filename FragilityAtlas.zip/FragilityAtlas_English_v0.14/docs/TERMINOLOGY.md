# FragilityAtlas terminology glossary

| Chinese concept / UI label | Approved English |
|---|---|
| 基本信息 | Basic Information |
| 函数数据库 | Fragility Database |
| 日本经典曲线 | Japan Classic Curves |
| 文献 Agent 工作台 | Literature Agent Workbench |
| 文献检索 | Literature retrieval |
| DeepSeek 辅助文献检索 | DeepSeek-assisted literature retrieval |
| PDF 函数提取 | PDF-based function extraction |
| 原文核验 / 来源核验 | Source verification |
| 人工核验 | Human verification |
| 候选函数记录 | Candidate function records |
| 已发布数据库 | Published database |
| 已核验 JSON 快照 | Verified JSON snapshot |
| 地震强度指标 | Ground-motion intensity measure (IM) |
| 损伤状态 | Damage state |
| 损伤状态超越概率 | Damage-state exceedance probability |
| 易损性函数 | Fragility function |
| 易损性曲线 | Fragility curve |
| 适用记录 | Applicability record |
| 去重曲线记录 | Deduplicated curve record |
| 曲线组 | Curve group |
| 连续概率函数 | Continuous probability function |
| 离散超越概率表 | Discrete exceedance-probability table |
| 损伤概率矩阵 | Damage probability matrix |
| 原文证据 | Original-source evidence |
| 原文定位 | Original-source location |
| 函数表达式 | Function expression |
| 参数候选表 | Parameter-candidate table |
| 检索结果 | Search results |
| 下载记录 | Download records |
| 运行报告 | Process report |
| 筛选 / 计算 / 绘图 | Filter / Calculate / Plot |
| 只读浏览 | Read-only browsing |
| 待核验 / 已核验 / 排除 | Pending verification / Verified / Excluded |

Keep Curve_ID, Group_ID, source-specific building codes, original damage-state labels, equations, DOIs, and original publication titles unchanged.
